# Jonathan Glenn's Python Learning Sandbox

## Overview
An interactive, browser-based Python learning platform built as a single-page web app. Users can write and execute real Python code directly in the browser using Pyodide (Python compiled to WebAssembly) — no installation required.

## Features
- **Welcome/About Me page** with a "Start Coding!" entry point
- **Interactive Python editor** with syntax highlighting (Prism.js) and live preview
- **16 Showcase Projects**: Guess the Number, Calculator, ASCII Art, Mad Libs, To-Do List, Quiz Game, Caesar Cipher, Dice Roller, BMI Calculator, Fibonacci, Patterns, Temperature Converter, Word Counter, Grade Book, Rock Paper Scissors, and more
- **18 Learning Samples**: Hello World, loops, list operations, recursion, OOP, error handling, comprehensions, and more
- **Python Built-in Functions Cheat Sheet**: 50+ functions with toggleable code examples
- **Standard Library Highlights**: math, random, os, sys, json, datetime, re, collections, itertools

## Architecture
- `index.html` — single-file application (HTML + CSS + JS)
- `server.py` — simple Python HTTP server serving on port 5000
- Python execution powered by **Pyodide v0.25.1** (loaded from CDN)
- Syntax highlighting via **Prism.js** (loaded from CDN)

## Running the App
The "Start application" workflow runs `python server.py` on port 5000.

## User Preferences
- Keep the app as a single `index.html` for simplicity and portability
