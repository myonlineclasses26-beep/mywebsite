    function showSection(id) {
      console.log('showSection called for:', id);
      document.querySelectorAll('.tab-section').forEach(function(s) {
        s.classList.remove('active');
      });
      document.querySelectorAll('#siteNav a').forEach(function(a) {
        a.classList.remove('active');
      });
      var sec = document.getElementById(id);
      console.log('found section:', sec ? sec.id : 'null');
      if (sec) sec.classList.add('active');
      var link = document.querySelector('#siteNav a[data-section="' + id + '"]');
      if (link) link.classList.add('active');
      history.replaceState(null, '', '#' + id);
      if (id === 'sec-editor' && sec) {
        sec.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
      if (id === 'sec-vocab') {
        onVocabPageShown();
      }
      if (id === 'sec-admin') {
        onAdminPageShown();
      }
    }

    function startCoding() {
      document.getElementById('welcomePage').style.display = 'none';
      document.getElementById('mainApp').style.display = '';
      var hash = window.location.hash.replace('#', '');
      var target = hash && document.getElementById(hash) ? hash : 'sec-editor';
      showSection(target);
    }

    function loadShowcase() {
      document.getElementById('samples').selectedIndex = 0;
      const showcases = {
        guessing: `# ============================================
#  GUESS THE NUMBER GAME
#  The computer picks a secret number 1-20.
#  Change "guess" below and Run to play!
# ============================================
import random

secret = random.randint(1, 20)
attempts = 0

# --- Change your guess here and hit Run! ---
guesses = [10, 5, 15, 12, 14]  # simulated guesses

print("=== Guess the Number! (1 - 20) ===")
for guess in guesses:
    attempts += 1
    print(f"Guess #{attempts}: {guess}", end="  →  ")
    if guess < secret:
        print("Too low! ⬆")
    elif guess > secret:
        print("Too high! ⬇")
    else:
        print(f"🎉 CORRECT! Got it in {attempts} guess(es)!")
        break
else:
    print(f"\\nThe secret number was: {secret}")
    print("Better luck next time!")`,

        calculator: `# ============================================
#  FOUR-FUNCTION CALCULATOR
#  Change a, b, and op below, then Run!
# ============================================

a  = 48       # ← Change me
b  = 6        # ← Change me
op = "÷"      # ← Choose: + - × ÷

print("=" * 30)
print("   CALCULATOR")
print("=" * 30)

if op == "+":
    result = a + b
elif op == "-":
    result = a - b
elif op == "×" or op == "*":
    result = a * b
elif op == "÷" or op == "/":
    if b == 0:
        print("Error: Can't divide by zero!")
        result = None
    else:
        result = a / b
else:
    print(f"Unknown operator: {op}")
    result = None

if result is not None:
    print(f"  {a}  {op}  {b}  =  {result}")

# --- Bonus: show all four operations at once ---
print("\\nAll operations:")
print(f"  {a} + {b} = {a + b}")
print(f"  {a} - {b} = {a - b}")
print(f"  {a} × {b} = {a * b}")
if b != 0:
    print(f"  {a} ÷ {b} = {a / b:.4f}")`,

        smiley: `# ============================================
#  ASCII ART COLLECTION
#  Run to see all the characters!
# ============================================

def draw_smiley():
    print("   *****   ")
    print(" *       * ")
    print("*  O   O  *")
    print("*    ^    *")
    print("*  \\___/  *")
    print(" *       * ")
    print("   *****   ")

def draw_star():
    for i in range(5):
        print(" " * (4 - i) + "*" * (2 * i + 1))
    for i in range(3, -1, -1):
        print(" " * (4 - i) + "*" * (2 * i + 1))

def draw_diamond(n=4):
    for i in range(n):
        print(" " * (n - i - 1) + "* " * (i + 1))
    for i in range(n - 2, -1, -1):
        print(" " * (n - i - 1) + "* " * (i + 1))

print("=== SMILEY FACE ===")
draw_smiley()
print("\\n=== STAR ===")
draw_star()
print("\\n=== DIAMOND ===")
draw_diamond()`,

        webpage: `# ============================================
#  HTML PAGE GENERATOR
#  Prints the source code of a web page
# ============================================

title   = "Jonathan's Python Page"
heading = "Hello from Python!"
items   = ["Python is fun", "Code runs in your browser", "No install needed"]

lines = []
lines.append("<!DOCTYPE html>")
lines.append("<html lang=\\"en\\">")
lines.append("  <head>")
lines.append(f"    <title>{title}</title>")
lines.append("  </head>")
lines.append("  <body>")
lines.append(f"    <h1>{heading}</h1>")
lines.append("    <ul>")
for item in items:
    lines.append(f"      <li>{item}</li>")
lines.append("    </ul>")
lines.append("    <p>Generated with Python!</p>")
lines.append("  </body>")
lines.append("</html>")

print("\\n".join(lines))
print(f"\\n--- Stats ---")
print(f"Lines of HTML: {len(lines)}")
print(f"List items:    {len(items)}")`,

        madlibs: `# ============================================
#  MAD LIBS STORY GENERATOR
#  Change the words below and Run!
# ============================================

# --- Fill in your own words! ---
name        = "Jonathan"
adjective1  = "sparkly"
noun1       = "penguin"
verb_past   = "danced"
place       = "the moon"
adjective2  = "enormous"
noun2       = "pizza"
number      = 42
body_part   = "elbow"

# --- The story ---
story = f"""
===========================================
           THE AMAZING STORY
===========================================

One day, {name} discovered a {adjective1} {noun1}
sitting quietly in the middle of {place}.

The {noun1} {verb_past} around an {adjective2}
{noun2} exactly {number} times before stopping.

Everyone clapped their {body_part}s in amazement.

The end. (Or is it...?)
===========================================
"""

print(story)
print(f"Word count: {len(story.split())}")`,

        todo: `# ============================================
#  TO-DO LIST MANAGER
#  A fully working task tracker in Python!
# ============================================

class TodoList:
    def __init__(self, owner):
        self.owner = owner
        self.tasks = []

    def add(self, task, priority="normal"):
        self.tasks.append({"task": task, "done": False, "priority": priority})

    def complete(self, index):
        if 0 <= index < len(self.tasks):
            self.tasks[index]["done"] = True

    def show(self):
        print(f"\\n{'='*40}")
        print(f"  {self.owner}'s To-Do List")
        print(f"{'='*40}")
        if not self.tasks:
            print("  No tasks yet!")
        for i, t in enumerate(self.tasks):
            status = "✅" if t["done"] else "⬜"
            pri    = f"[{t['priority'].upper()}]" if t["priority"] != "normal" else ""
            print(f"  {i+1}. {status} {t['task']} {pri}")
        done  = sum(1 for t in self.tasks if t["done"])
        total = len(self.tasks)
        print(f"{'='*40}")
        print(f"  Progress: {done}/{total} tasks complete")

# --- Demo ---
my_list = TodoList("Jonathan")
my_list.add("Study Python built-in functions", "high")
my_list.add("Build a cool project")
my_list.add("Review cheat sheet", "high")
my_list.add("Take a break")
my_list.add("Push code to GitHub")

my_list.show()

# Mark some done
my_list.complete(0)
my_list.complete(2)

my_list.show()`,

        quiz: `# ============================================
#  PYTHON TRIVIA QUIZ
#  Scores your answers automatically!
# ============================================

questions = [
    {
        "q": "What function returns the length of a list?",
        "choices": ["A) size()", "B) len()", "C) count()", "D) length()"],
        "answer": "B",
        "explanation": "len() counts items in any collection."
    },
    {
        "q": "Which symbol is used for exponentiation in Python?",
        "choices": ["A) ^", "B) exp()", "C) **", "D) ^^"],
        "answer": "C",
        "explanation": "Python uses ** for powers: 2**3 = 8"
    },
    {
        "q": "What does range(3) produce?",
        "choices": ["A) [1,2,3]", "B) [0,1,2,3]", "C) [0,1,2]", "D) (0,1,2,3)"],
        "answer": "C",
        "explanation": "range(n) starts at 0 and stops before n."
    },
    {
        "q": "What type does input() always return?",
        "choices": ["A) int", "B) float", "C) bool", "D) str"],
        "answer": "D",
        "explanation": "input() always returns a string — convert if needed!"
    },
    {
        "q": "Which keyword starts a function definition?",
        "choices": ["A) function", "B) fun", "C) def", "D) fn"],
        "answer": "C",
        "explanation": "def is short for 'define'."
    },
]

# --- Your answers here ---
your_answers = ["B", "C", "C", "D", "C"]

print("=" * 45)
print("       PYTHON KNOWLEDGE QUIZ")
print("=" * 45)

score = 0
for i, (q, ans) in enumerate(zip(questions, your_answers)):
    correct = ans.upper() == q["answer"]
    if correct:
        score += 1
    mark = "✅ Correct!" if correct else f"❌ Wrong  (Answer: {q['answer']})"
    print(f"\\nQ{i+1}: {q['q']}")
    print(f"     Your answer: {ans}  →  {mark}")
    if not correct:
        print(f"     💡 {q['explanation']}")

print("\\n" + "=" * 45)
pct = score / len(questions) * 100
print(f"  Score: {score}/{len(questions)}  ({pct:.0f}%)")
if pct == 100:
    print("  🏆 Perfect score! You're a Python pro!")
elif pct >= 80:
    print("  🎉 Great job! Almost there!")
elif pct >= 60:
    print("  👍 Good effort — keep studying!")
else:
    print("  📖 Review the cheat sheet below!")
print("=" * 45)`,

        cipher: `# ============================================
#  CAESAR CIPHER — Encode & Decode Messages
#  Change message and shift below!
# ============================================

def caesar_cipher(text, shift, mode="encode"):
    if mode == "decode":
        shift = -shift
    result = ""
    for ch in text:
        if ch.isalpha():
            base = ord("A") if ch.isupper() else ord("a")
            result += chr((ord(ch) - base + shift) % 26 + base)
        else:
            result += ch   # keep spaces, punctuation unchanged
    return result

# --- Change these! ---
message = "Hello Jonathan, Python is awesome!"
shift   = 13   # ROT-13 is shift=13 (most famous cipher)

encoded = caesar_cipher(message, shift, "encode")
decoded = caesar_cipher(encoded, shift, "decode")

print("=" * 50)
print("  CAESAR CIPHER  (shift =", shift, ")")
print("=" * 50)
print(f"  Original: {message}")
print(f"  Encoded:  {encoded}")
print(f"  Decoded:  {decoded}")
print("=" * 50)

# Brute-force all 26 shifts (codebreaker mode!)
print("\\n--- All 26 possible shifts ---")
for s in range(1, 27):
    attempt = caesar_cipher(encoded, s, "decode")
    print(f"  Shift {s:2d}: {attempt}")`,

        dice: `# ============================================
#  DICE ROLLER WITH STATISTICS
#  Change num_dice, sides, and rolls!
# ============================================
import random

num_dice = 2    # ← how many dice per roll
sides    = 6    # ← faces per die (d4, d6, d8, d10, d12, d20)
rolls    = 1000 # ← how many times to roll

print(f"Rolling {num_dice}d{sides} × {rolls} times...")

results = []
for _ in range(rolls):
    total = sum(random.randint(1, sides) for _ in range(num_dice))
    results.append(total)

min_val = min_val = num_dice
max_val = num_dice * sides

print("\\n=== RESULTS ===")
print(f"Min possible:  {min_val}")
print(f"Max possible:  {max_val}")
print(f"Actual min:    {min(results)}")
print(f"Actual max:    {max(results)}")
print(f"Average:       {sum(results)/len(results):.2f}")
print(f"Theoretical:   {(min_val + max_val) / 2:.2f}")

print("\\n=== DISTRIBUTION ===")
for val in range(min_val, max_val + 1):
    count = results.count(val)
    bar   = "█" * (count * 40 // rolls)
    pct   = count / rolls * 100
    print(f"  {val:3d} | {bar:<40} {pct:5.1f}%")`,

        bmi: `# ============================================
#  BMI CALCULATOR & HEALTH REPORT
#  Change height and weight below!
# ============================================

# --- Your measurements ---
name          = "Jonathan"
weight_lbs    = 170    # pounds
height_ft     = 5      # feet
height_in     = 10     # inches

# --- Conversions ---
weight_kg = weight_lbs * 0.453592
height_m  = (height_ft * 12 + height_in) * 0.0254
bmi       = weight_kg / (height_m ** 2)

# --- Category ---
if bmi < 18.5:
    category = "Underweight"
    advice   = "Consider speaking with a doctor about nutrition."
elif bmi < 25.0:
    category = "Normal weight ✅"
    advice   = "Great! Maintain your healthy habits."
elif bmi < 30.0:
    category = "Overweight"
    advice   = "Regular exercise and a balanced diet can help."
else:
    category = "Obese"
    advice   = "Please consult a healthcare professional."

print("=" * 42)
print(f"  BMI HEALTH REPORT — {name}")
print("=" * 42)
print(f"  Height:   {height_ft}'{height_in}\\\"  ({height_m:.2f} m)")
print(f"  Weight:   {weight_lbs} lbs  ({weight_kg:.1f} kg)")
print(f"  BMI:      {bmi:.1f}")
print(f"  Status:   {category}")
print(f"  Advice:   {advice}")
print("=" * 42)
print("\\nBMI Scale:")
print("  < 18.5  Underweight")
print("  18.5–24.9  Normal weight")
print("  25.0–29.9  Overweight")
print("  ≥ 30.0  Obese")`,

        fibonacci: `# ============================================
#  FIBONACCI SEQUENCE EXPLORER
#  Change n to see more or fewer numbers!
# ============================================

def fibonacci(n):
    """Generate the first n Fibonacci numbers."""
    seq = []
    a, b = 0, 1
    for _ in range(n):
        seq.append(a)
        a, b = b, a + b
    return seq

def is_fibonacci(num):
    """Check if a number is in the Fibonacci sequence."""
    a, b = 0, 1
    while a < num:
        a, b = b, a + b
    return a == num

n = 20  # ← Change me!
seq = fibonacci(n)

print(f"First {n} Fibonacci Numbers")
print("=" * 50)

for i, val in enumerate(seq):
    bar = "█" * (val * 30 // max(seq, default=1) + 1) if val > 0 else "█"
    print(f"  F({i:2d}) = {val:8,}  {bar}")

print("=" * 50)
print(f"\\nLast value:  {seq[-1]:,}")
print(f"Sum of all:  {sum(seq):,}")

# Golden Ratio approximation
if len(seq) >= 2 and seq[-2] != 0:
    ratio = seq[-1] / seq[-2]
    print(f"F({n-1})/F({n-2}): {ratio:.8f}  (golden ratio ≈ 1.61803399)")`,

        patterns: `# ============================================
#  ASCII ART PATTERN GENERATOR
#  Change 'size' or try different patterns!
# ============================================

size = 7  # ← Change me!

def right_triangle(n):
    print("--- Right Triangle ---")
    for i in range(1, n + 1):
        print("*" * i)

def pyramid(n):
    print("--- Pyramid ---")
    for i in range(1, n + 1):
        spaces = " " * (n - i)
        stars  = "*" * (2 * i - 1)
        print(spaces + stars)

def hollow_square(n):
    print("--- Hollow Square ---")
    for i in range(n):
        if i == 0 or i == n - 1:
            print("*" * n)
        else:
            print("*" + " " * (n - 2) + "*")

def checkerboard(n):
    print("--- Checkerboard ---")
    for i in range(n):
        row = ""
        for j in range(n):
            row += "# " if (i + j) % 2 == 0 else ". "
        print(row)

def number_triangle(n):
    print("--- Number Triangle ---")
    for i in range(1, n + 1):
        print(" ".join(str(j) for j in range(1, i + 1)))

right_triangle(size)
print()
pyramid(size)
print()
hollow_square(size)
print()
checkerboard(size)
print()
number_triangle(size)`,

        temperature: `# ============================================
#  TEMPERATURE CONVERTER
#  Convert between °C, °F, and K
# ============================================

def celsius_to_fahrenheit(c):
    return (c * 9/5) + 32

def celsius_to_kelvin(c):
    return c + 273.15

def fahrenheit_to_celsius(f):
    return (f - 32) * 5/9

def kelvin_to_celsius(k):
    return k - 273.15

def convert_all(value, unit):
    unit = unit.upper()
    if unit == "C":
        c = value
    elif unit == "F":
        c = fahrenheit_to_celsius(value)
    elif unit == "K":
        c = kelvin_to_celsius(value)
    else:
        print("Unknown unit — use C, F, or K")
        return
    f = celsius_to_fahrenheit(c)
    k = celsius_to_kelvin(c)
    print(f"  {value}°{unit}  =  {c:.2f}°C  =  {f:.2f}°F  =  {k:.2f} K")

print("=" * 50)
print("     TEMPERATURE CONVERTER")
print("=" * 50)

readings = [
    (0,   "C"),   # Freezing point of water
    (100, "C"),   # Boiling point of water
    (98.6,"F"),   # Normal body temperature
    (72,  "F"),   # Room temperature
    (0,   "K"),   # Absolute zero
    (37,  "C"),   # Body temp in Celsius
]

for val, unit in readings:
    convert_all(val, unit)

print("\\n--- Common Reference Points ---")
refs = [("Absolute zero", -273.15), ("Water freezes", 0),
        ("Room temp", 22), ("Body temp", 37), ("Water boils", 100)]
print(f"{'Point':<20} {'°C':>6} {'°F':>8} {'K':>8}")
print("-" * 45)
for label, c in refs:
    print(f"{label:<20} {c:>6.1f} {celsius_to_fahrenheit(c):>8.1f} {celsius_to_kelvin(c):>8.2f}")`,

        wordcount: `# ============================================
#  WORD COUNTER & TEXT ANALYZER
#  Change 'text' below to analyze anything!
# ============================================

text = """
Python is a versatile and beginner-friendly programming language.
It is used for web development, data science, artificial intelligence,
and automation. Python code is clean, readable, and fun to write.
Many top companies use Python, including Google, NASA, and Netflix.
Python is one of the most popular languages in the world today.
"""

words      = text.split()
sentences  = [s.strip() for s in text.replace("\\n", " ").split(".") if s.strip()]
lines      = [l for l in text.strip().split("\\n") if l.strip()]
chars_all  = len(text)
chars_no_sp = len(text.replace(" ", "").replace("\\n", ""))

# Word frequency (case-insensitive, strip punctuation)
import string
freq = {}
for w in words:
    clean = w.lower().strip(string.punctuation)
    if clean:
        freq[clean] = freq.get(clean, 0) + 1

top_words = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:10]

print("=" * 45)
print("     TEXT ANALYSIS REPORT")
print("=" * 45)
print(f"  Lines:              {len(lines)}")
print(f"  Sentences:          {len(sentences)}")
print(f"  Words:              {len(words)}")
print(f"  Unique words:       {len(freq)}")
print(f"  Characters (total): {chars_all}")
print(f"  Characters (no sp): {chars_no_sp}")
avg = len(words) / len(sentences) if sentences else 0
print(f"  Avg words/sentence: {avg:.1f}")
print("\\n  Top 10 Words:")
for word, count in top_words:
    bar = "▪" * count
    print(f"    {word:<15} {count:3d}  {bar}")`,

        grade: `# ============================================
#  GRADE BOOK & REPORT CARD
#  Edit students and scores below!
# ============================================

students = {
    "Alice":    [95, 88, 92, 97, 89],
    "Bob":      [72, 65, 78, 70, 68],
    "Carol":    [88, 91, 85, 94, 90],
    "David":    [55, 60, 48, 72, 58],
    "Jonathan": [98, 97, 100, 95, 99],
}

assignments = ["Homework", "Quiz 1", "Quiz 2", "Midterm", "Final"]

def letter_grade(avg):
    if avg >= 90: return "A"
    elif avg >= 80: return "B"
    elif avg >= 70: return "C"
    elif avg >= 60: return "D"
    else: return "F"

def gpa_points(avg):
    if avg >= 90: return 4.0
    elif avg >= 80: return 3.0
    elif avg >= 70: return 2.0
    elif avg >= 60: return 1.0
    else: return 0.0

print("=" * 60)
print("                 REPORT CARD")
print("=" * 60)
print(f"{'Name':<12}", end="")
for a in assignments:
    print(f" {a[:8]:>8}", end="")
print(f"  {'Avg':>5}  {'Grade':>5}  {'GPA':>4}")
print("-" * 60)

class_avgs = []
for name, scores in students.items():
    avg = sum(scores) / len(scores)
    class_avgs.append(avg)
    grade = letter_grade(avg)
    gpa   = gpa_points(avg)
    print(f"{name:<12}", end="")
    for s in scores:
        print(f" {s:>8}", end="")
    print(f"  {avg:>5.1f}  {grade:>5}  {gpa:>4.1f}")

print("=" * 60)
class_avg = sum(class_avgs) / len(class_avgs)
print(f"Class average: {class_avg:.1f}  ({letter_grade(class_avg)})")
top = max(students.keys(), key=lambda n: sum(students[n])/len(students[n]))
print(f"Top student:   {top}")`,

        rockpaper: `# ============================================
#  ROCK PAPER SCISSORS — vs the Computer!
#  Change your_moves to play differently
# ============================================
import random

choices = ["rock", "paper", "scissors"]

def beats(a, b):
    """Return True if a beats b."""
    return (a == "rock"     and b == "scissors") or \\
           (a == "scissors" and b == "paper")    or \\
           (a == "paper"    and b == "rock")

def emoji(choice):
    return {"rock": "🪨", "paper": "📄", "scissors": "✂️"}.get(choice, "?")

# --- Your moves (change these!) ---
your_moves = ["rock", "scissors", "paper", "rock", "scissors",
              "paper", "paper", "rock", "scissors", "paper"]

wins = losses = ties = 0

print("=" * 40)
print("   ROCK  PAPER  SCISSORS")
print("=" * 40)

for i, you in enumerate(your_moves):
    computer = random.choice(choices)
    if beats(you, computer):
        result = "You win! 🎉"
        wins += 1
    elif beats(computer, you):
        result = "Computer wins 🤖"
        losses += 1
    else:
        result = "Tie 🤝"
        ties += 1
    print(f"  Round {i+1:2d}: {emoji(you)} vs {emoji(computer)}  → {result}")

total = wins + losses + ties
print("=" * 40)
print(f"  Wins:   {wins}/{total}")
print(f"  Losses: {losses}/{total}")
print(f"  Ties:   {ties}/{total}")
win_rate = wins / total * 100 if total else 0
print(f"  Win rate: {win_rate:.1f}%")
if win_rate > 50:
    print("  You're on fire! 🔥")
elif win_rate == 50:
    print("  Dead even!")`,

        password: `# ============================================
#  SECURE PASSWORD GENERATOR
#  Change length and toggle symbols!
# ============================================
import random, string

length      = 16      # ← how many characters
use_symbols = True    # ← include !@#$%^&*?

chars = string.ascii_letters + string.digits
if use_symbols:
    chars += "!@#$%^&*?"

password = "".join(random.choice(chars) for _ in range(length))

print("=" * 40)
print("  SECURE PASSWORD GENERATOR")
print("=" * 40)
print(f"  Length:      {length}")
print(f"  Symbols:     {'Yes' if use_symbols else 'No'}")
print(f"  Password:    {password}")
print("=" * 40)

# Strength check
categories = 0
if any(c.islower() for c in password): categories += 1
if any(c.isupper() for c in password): categories += 1
if any(c.isdigit() for c in password): categories += 1
if any(c in "!@#$%^&*?" for c in password): categories += 1
strength = ["Weak", "Fair", "Good", "Strong", "Excellent"][categories]
print(f"  Strength:    {strength}")`,

        hangman: `# ============================================
#  HANGMAN — Guess the word before it's too late!
#  Add more words to make it harder!
# ============================================
import random

words = ["python", "javascript", "hangman", "developer", "keyboard", "monitor", "algorithm"]
word = random.choice(words)
guessed = set()
wrong = 0
max_wrong = 6

stages = [
    "  ┌───┐\\n  |   |\\n      |\\n      |\\n      |\\n      |\\n──────┘",
    "  ┌───┐\\n  |   |\\n  O   |\\n      |\\n      |\\n      |\\n──────┘",
    "  ┌───┐\\n  |   |\\n  O   |\\n  |   |\\n      |\\n      |\\n──────┘",
    "  ┌───┐\\n  |   |\\n  O   |\\n /|   |\\n      |\\n      |\\n──────┘",
    "  ┌───┐\\n  |   |\\n  O   |\\n /|\\  |\\n      |\\n      |\\n──────┘",
    "  ┌───┐\\n  |   |\\n  O   |\\n /|\\  |\\n /    |\\n      |\\n──────┘",
    "  ┌───┐\\n  |   |\\n  O   |\\n /|\\  |\\n / \\  |\\n      |\\n──────┘",
]

print("=" * 40)
print("   H A N G M A N")
print("=" * 40)

while wrong < max_wrong:
    display = " ".join(c if c in guessed else "_" for c in word)
    print(f"\\nWord: {display}")
    print(f"Wrong guesses: {wrong}/{max_wrong}")
    print(stages[wrong])

    if "_" not in display:
        print("\\n🎉 You win! The word was:", word)
        break

    # Simulate guesses for demo
    for guess in "aeiouplmn":
        if guess not in guessed:
            guessed.add(guess)
            if guess not in word:
                wrong += 1
            break

if "_" in display:
    print("\\n💀 Game over! The word was:", word)`,

        contacts: `# ============================================
#  CONTACT BOOK MANAGER
#  Add, search, and list your contacts!
# ============================================

contacts = {
    "Alice": {"phone": "555-0101", "email": "alice@example.com"},
    "Bob":   {"phone": "555-0202", "email": "bob@example.com"},
}

def add_contact(name, phone, email):
    contacts[name] = {"phone": phone, "email": email}
    print(f"Added {name} to contacts.")

def search_contact(name):
    if name in contacts:
        info = contacts[name]
        print(f"  {name}:")
        print(f"    Phone: {info['phone']}")
        print(f"    Email: {info['email']}")
    else:
        print(f"  '{name}' not found.")

def list_contacts():
    print("\\nAll Contacts:")
    for name, info in contacts.items():
        print(f"  {name:<10} {info['phone']}  {info['email']}")

# --- Demo ---
add_contact("Carol", "555-0303", "carol@example.com")
print()
search_contact("Alice")
search_contact("Dave")
print()
list_contacts()`,

        number_guess_ai: `# ============================================
#  AI NUMBER GUESSER — Computer guesses YOUR number!
#  Think of a number 1-100 and watch binary search work
# ============================================

print("Think of a number between 1 and 100...")
print("I'll guess it using binary search!\\n")

low, high = 1, 100
guesses = 0

# Pre-set the "secret" number for demo
secret = 42

while low <= high:
    guess = (low + high) // 2
    guesses += 1
    print(f"  Guess #{guesses}: {guess}")

    if guess == secret:
        print(f"  🎯 Found it! The number is {guess}")
        print(f"  Took only {guesses} guesses (out of 100 possible!)")
        break
    elif guess < secret:
        print(f"  Too low. Adjusting range...")
        low = guess + 1
    else:
        print(f"  Too high. Adjusting range...")
        high = guess - 1

print(f"\\nBinary search efficiency: log₂(100) ≈ {guesses} guesses")`
      };

      const breakdowns = {
        guessing: `<strong>What it does:</strong> Simulates a number guessing game with feedback each round.<br>
<strong>Try it:</strong> Change the numbers in the <code>guesses</code> list and run again — can you guess the secret number?<br>
<strong>Concepts used:</strong> <code>random.randint()</code>, <code>for</code> loop, <code>if/elif/else</code>, f-strings.`,

        calculator: `<strong>What it does:</strong> Performs all four math operations on two numbers.<br>
<strong>Try it:</strong> Change <code>a</code>, <code>b</code>, and <code>op</code> at the top.<br>
<strong>Concepts used:</strong> Variables, <code>if/elif/else</code>, division by zero check, f-strings.`,

        smiley: `<strong>What it does:</strong> Draws three ASCII art shapes using functions.<br>
<strong>Try it:</strong> Modify the stars or add your own shape function!<br>
<strong>Concepts used:</strong> Functions, <code>for</code> loops, string multiplication, <code>range()</code>.`,

        webpage: `<strong>What it does:</strong> Generates the source code of a real HTML web page.<br>
<strong>Try it:</strong> Change <code>title</code>, <code>heading</code>, or the <code>items</code> list.<br>
<strong>Concepts used:</strong> F-strings, lists, <code>for</code> loop, <code>join()</code>.`,

        madlibs: `<strong>What it does:</strong> Fills a story template with your custom words.<br>
<strong>Try it:</strong> Change any of the word variables at the top — be creative!<br>
<strong>Concepts used:</strong> Variables, f-strings, multi-line strings, <code>split()</code>.`,

        todo: `<strong>What it does:</strong> A full to-do list manager with priorities and a progress tracker.<br>
<strong>Try it:</strong> Add more tasks with <code>my_list.add()</code> or mark others complete with <code>my_list.complete(index)</code>.<br>
<strong>Concepts used:</strong> Classes, methods, lists of dicts, f-strings, <code>sum()</code>.`,

        quiz: `<strong>What it does:</strong> A self-grading Python trivia quiz with explanations.<br>
<strong>Try it:</strong> Change the answers in <code>your_answers</code> and see your score change!<br>
<strong>Concepts used:</strong> Lists of dicts, <code>zip()</code>, <code>enumerate()</code>, percentage math.`,

        cipher: `<strong>What it does:</strong> Encodes and decodes secret messages using the Caesar cipher shift.<br>
<strong>Try it:</strong> Change <code>message</code> and <code>shift</code> — shift=13 is the classic ROT-13 cipher.<br>
<strong>Concepts used:</strong> <code>ord()</code>, <code>chr()</code>, modular arithmetic, string building.`,

        dice: `<strong>What it does:</strong> Rolls dice thousands of times and shows the statistical distribution.<br>
<strong>Try it:</strong> Change <code>num_dice</code> (try 3), <code>sides</code> (try 20), or <code>rolls</code>.<br>
<strong>Concepts used:</strong> <code>random.randint()</code>, list comprehension, statistics, bar chart.`,

        bmi: `<strong>What it does:</strong> Calculates BMI and gives a health category and advice.<br>
<strong>Try it:</strong> Change <code>weight_lbs</code>, <code>height_ft</code>, and <code>height_in</code> at the top.<br>
<strong>Concepts used:</strong> Unit conversion math, <code>if/elif/else</code>, f-strings.`,

        fibonacci: `<strong>What it does:</strong> Generates the Fibonacci sequence and shows an ASCII bar chart.<br>
<strong>Try it:</strong> Change <code>n</code> to 10 or 30 — watch the golden ratio get more accurate!<br>
<strong>Concepts used:</strong> Functions, tuple unpacking (<code>a, b = b, a + b</code>), list building.`,

        patterns: `<strong>What it does:</strong> Draws five different ASCII art patterns using loops.<br>
<strong>Try it:</strong> Change <code>size</code> at the top and run — try values from 3 to 15.<br>
<strong>Concepts used:</strong> Functions, nested <code>for</code> loops, string multiplication.`,

        temperature: `<strong>What it does:</strong> Converts temperatures between Celsius, Fahrenheit, and Kelvin.<br>
<strong>Try it:</strong> Add your own temperatures to the <code>readings</code> list.<br>
<strong>Concepts used:</strong> Functions, conversion formulas, f-string table formatting.`,

        wordcount: `<strong>What it does:</strong> Analyzes a block of text — word count, frequency, stats.<br>
<strong>Try it:</strong> Replace <code>text</code> with any paragraph and see the analysis change.<br>
<strong>Concepts used:</strong> <code>split()</code>, dictionaries, <code>sorted()</code> with key, the <code>string</code> module.`,

        grade: `<strong>What it does:</strong> Prints a formatted report card with averages, letter grades, and GPA.<br>
<strong>Try it:</strong> Add a new student to the <code>students</code> dict with 5 scores.<br>
<strong>Concepts used:</strong> Nested dicts, functions, <code>max()</code> with key, f-string table alignment.`,

        rockpaper: `<strong>What it does:</strong> Plays Rock Paper Scissors with the computer and tracks your record.<br>
<strong>Try it:</strong> Change the moves in <code>your_moves</code> — or add more rounds!<br>
<strong>Concepts used:</strong> Functions, <code>random.choice()</code>, dictionaries, win/loss logic.`,

        password: `<strong>What it does:</strong> Generates strong random passwords with letters, numbers, and symbols.<br>
<strong>Try it:</strong> Change <code>length</code> or toggle <code>use_symbols</code>!<br>
<strong>Concepts used:</strong> <code>random.choice()</code>, string constants, loops, list comprehension.`,

        hangman: `<strong>What it does:</strong> A classic word-guessing game with visual hangman drawing.<br>
<strong>Try it:</strong> Add more words to the <code>words</code> list!<br>
<strong>Concepts used:</strong> <code>while</code> loops, sets, string manipulation, ASCII art.`,

        contacts: `<strong>What it does:</strong> A mini contact manager — add, search, and list contacts.<br>
<strong>Try it:</strong> Add more contacts or try the search feature!<br>
<strong>Concepts used:</strong> Dictionaries, functions, loops, string methods.`,

        number_guess_ai: `<strong>What it does:</strong> The computer guesses YOUR number using binary search!<br>
<strong>Try it:</strong> Think of a number between 1 and 100 and see how fast the AI finds it.<br>
<strong>Concepts used:</strong> Binary search, <code>while</code> loops, math logic, user simulation.`
      };

      const val = document.getElementById('showcase').value;
      document.getElementById('codeInput').value = showcases[val] || "";
      previewCode.textContent = document.getElementById('codeInput').value;
      Prism.highlightElement(previewCode);
      const explainBox = document.getElementById('sampleExplain');
      if (val && breakdowns[val]) {
        explainBox.style.display = "";
        explainBox.innerHTML = breakdowns[val];
      } else {
        explainBox.style.display = "none";
        explainBox.textContent = "";
      }
    }

    function loadSample() {
      document.getElementById('showcase').selectedIndex = 0;
      const samples = {
        hello: `# The classic first program!
# print() displays text to the screen.

print("Hello, world!")
print("My name is Jonathan Glenn.")
print("I'm learning Python!")

# You can print numbers too
print("The answer is:", 42)
print("Pi is approximately:", 3.14159)`,

        loop: `# For loops repeat code a set number of times.
# range(start, stop) gives us the numbers to loop over.

print("Counting from 1 to 10:")
for i in range(1, 11):
    print(f"  {i}")

print("\\nEven numbers from 2 to 20:")
for i in range(2, 21, 2):   # step of 2
    print(f"  {i}", end=" ")

print("\\n\\nCountdown!")
for i in range(5, 0, -1):   # count backwards
    print(f"  {i}...")
print("  Blast off! 🚀")`,

        list_sum: `# Lists hold multiple values in one variable.
# Built-in functions like sum(), max(), min() work on them.

scores = [88, 92, 75, 100, 67, 84, 91]

print("Scores:", scores)
print("Total:  ", sum(scores))
print("Highest:", max(scores))
print("Lowest: ", min(scores))
print("Count:  ", len(scores))

average = sum(scores) / len(scores)
print(f"Average: {average:.1f}")

# Passing score is 70
passing = [s for s in scores if s >= 70]
failing = [s for s in scores if s < 70]
print(f"\\nPassing ({len(passing)}): {passing}")
print(f"Failing  ({len(failing)}): {failing}")`,

        string_reverse: `# Strings are sequences — you can slice and reverse them!

word = "Python"
print("Original: ", word)
print("Reversed: ", word[::-1])   # slice with step -1

# Practical uses
sentence = "racecar"
if sentence == sentence[::-1]:
    print(f"'{sentence}' is a palindrome!")

words = ["hello", "level", "world", "madam", "python"]
print("\\nPalindrome check:")
for w in words:
    result = "✅ palindrome" if w == w[::-1] else "❌ not a palindrome"
    print(f"  {w:<10} → {result}")

# Reverse words in a sentence
phrase = "Python is awesome"
reversed_words = " ".join(phrase.split()[::-1])
print(f"\\nOriginal: {phrase}")
print(f"Reversed: {reversed_words}")`,

        factorial: `# Recursion — a function that calls itself!
# factorial(n) = n × (n-1) × (n-2) × ... × 1

def factorial(n):
    if n <= 1:
        return 1                    # base case: stop here
    return n * factorial(n - 1)    # recursive case

# Show the calculation step by step
print("Factorials:")
for n in range(1, 11):
    print(f"  {n:2d}! = {factorial(n):,}")

# Real use: how many ways to arrange n items?
items = 5
arrangements = factorial(items)
print(f"\\nWays to arrange {items} different books on a shelf:")
print(f"  {items}! = {arrangements:,}")`,

        fstring: `# F-strings (formatted string literals) — the modern way
# to embed variables and expressions inside strings.
# Just put f before the quote and wrap variables in { }

name  = "Jonathan"
age   = 21
gpa   = 3.94
major = "AI Software Engineering"

# Basic variable insertion
print(f"Name: {name}")
print(f"Age:  {age}")

# Expressions inside {}
print(f"In 5 years: {age + 5} years old")
print(f"GPA rounded: {round(gpa, 1)}")

# Format specifiers
price = 1999.999
print(f"Price:      ${"$"}{price:,.2f}")        # thousands separator, 2 decimals
print(f"As percent: {gpa / 4.0:.1%}")      # percentage
print(f"Padded:     {name:>20}")            # right-align in 20 chars
print(f"Padded:     {name:<20}|")           # left-align

# Multi-line f-string
card = f"""
┌─────────────────────────────┐
│  Student ID Card            │
│  Name:  {name:<20} │
│  Major: {major[:20]:<20} │
│  GPA:   {gpa:<20.2f} │
└─────────────────────────────┘
"""
print(card)`,

        dict_basics: `# Dictionaries store key → value pairs.
# Think of them like a real dictionary: look up a word (key),
# get its definition (value).

# Create a dictionary
person = {
    "name":   "Jonathan Glenn",
    "age":    21,
    "major":  "AI Engineering",
    "gpa":    3.9,
    "enrolled": True,
}

# Access values
print("Name:", person["name"])
print("GPA: ", person["gpa"])

# Safe access with .get() — won't crash if key is missing
print("Phone:", person.get("phone", "N/A"))

# Add / update
person["year"] = 2
person["gpa"]  = 4.0

# Loop over keys and values
print("\\nFull Profile:")
for key, value in person.items():
    print(f"  {key:10}: {value}")

# Check if a key exists
if "major" in person:
    print(f"\\nStudying: {person['major']}")

# Remove a key
removed = person.pop("enrolled")
print(f"Removed 'enrolled': {removed}")
print(f"Keys left: {list(person.keys())}")`,

        list_comp: `# List comprehensions — a compact, readable way to
# build a new list by transforming or filtering another list.

# --- Basic syntax: [expression for item in iterable] ---

# Old way (loop)
squares_loop = []
for n in range(1, 11):
    squares_loop.append(n ** 2)

# New way (comprehension) — same result, one line!
squares = [n ** 2 for n in range(1, 11)]
print("Squares:", squares)

# --- With a filter: [expr for item in iterable if condition] ---
evens = [n for n in range(1, 21) if n % 2 == 0]
print("Evens:  ", evens)

# --- Transform strings ---
words = ["hello", "WORLD", "  Python  ", "code"]
clean = [w.strip().lower() for w in words]
print("Cleaned:", clean)

# --- Nested: multiplication table ---
print("\\nMultiplication Table (3×3):")
table = [[r * c for c in range(1, 4)] for r in range(1, 4)]
for row in table:
    print("  ", row)

# --- Dictionary comprehension ---
scores = {"Alice": 88, "Bob": 72, "Carol": 95}
passed = {name: score for name, score in scores.items() if score >= 75}
print("\\nPassed:", passed)`,

        while_loop: `# While loops keep running as long as a condition is True.
# Use them when you don't know in advance how many iterations you need.

# --- Basic while loop ---
count = 1
print("Counting to 5:")
while count <= 5:
    print(f"  {count}")
    count += 1   # Don't forget to update — or it loops forever!

# --- Simulate a bank account ---
print("\\nATM Simulation:")
balance  = 500.00
withdraw = [100, 200, 150, 75, 300]  # attempted withdrawals

for amount in withdraw:
    if balance >= amount:
        balance -= amount
        print(f"  Withdrew ${"$"}{amount:.2f}  →  Balance: ${"$"}{balance:.2f}")
    else:
        print(f"  ❌ Insufficient funds for ${"$"}{amount:.2f} (balance: ${"$"}{balance:.2f})")

# --- while with a break ---
print("\\nFirst number divisible by 7 above 100:")
n = 101
while True:
    if n % 7 == 0:
        print(f"  Found: {n}")
        break
    n += 1`,

        functions: `# Functions let you name and reuse a block of code.
# Parameters go in (), and you can return a value with 'return'.

# --- Simple function ---
def greet(name):
    return f"Hello, {name}!"

print(greet("Jonathan"))
print(greet("World"))

# --- Default parameter value ---
def power(base, exponent=2):
    return base ** exponent

print(power(5))       # 25  (uses default exponent=2)
print(power(2, 10))   # 1024

# --- Multiple return values ---
def min_max_avg(numbers):
    return min(numbers), max(numbers), sum(numbers) / len(numbers)

scores = [88, 72, 95, 61, 84]
low, high, avg = min_max_avg(scores)
print(f"\\nScores: {scores}")
print(f"Min: {low}  Max: {high}  Avg: {avg:.1f}")

# --- *args — accept any number of arguments ---
def total(*prices):
    subtotal = sum(prices)
    tax      = subtotal * 0.08
    return subtotal, tax, subtotal + tax

sub, tax, grand = total(9.99, 14.50, 4.00, 22.00)
print(f"\\nSubtotal: ${"$"}{sub:.2f}")
print(f"Tax:      ${"$"}{tax:.2f}")
print(f"Total:    ${"$"}{grand:.2f}")`,

        classes: `# Classes are blueprints for creating objects.
# Objects have attributes (data) and methods (functions).

class Dog:
    # __init__ runs when you create a new Dog
    def __init__(self, name, breed, age):
        self.name  = name
        self.breed = breed
        self.age   = age
        self.tricks = []

    def speak(self):
        return f"{self.name} says: Woof!"

    def learn_trick(self, trick):
        self.tricks.append(trick)
        return f"{self.name} learned '{trick}'!"

    def show_tricks(self):
        if not self.tricks:
            return f"{self.name} doesn't know any tricks yet."
        return f"{self.name} knows: {', '.join(self.tricks)}"

    def __str__(self):
        return f"Dog({self.name}, {self.breed}, {self.age}yo)"

# Create instances (objects)
rex   = Dog("Rex",   "German Shepherd", 3)
buddy = Dog("Buddy", "Golden Retriever", 5)

print(rex.speak())
print(buddy.speak())

print(rex.learn_trick("sit"))
print(rex.learn_trick("shake"))
print(rex.learn_trick("roll over"))
print(rex.show_tricks())
print(buddy.show_tricks())

print(f"\\nDogs: {rex}, {buddy}")`,

        error_handling: `# Errors happen — try/except lets you handle them gracefully
# instead of crashing the whole program.

# --- Basic try/except ---
def safe_divide(a, b):
    try:
        return a / b
    except ZeroDivisionError:
        return "Error: Can't divide by zero!"

print(safe_divide(10, 2))    # 5.0
print(safe_divide(10, 0))    # Error: Can't divide by zero!

# --- Multiple except blocks ---
def parse_number(text):
    try:
        return int(text)
    except ValueError:
        try:
            return float(text)
        except ValueError:
            return f"'{text}' is not a number"

inputs = ["42", "3.14", "hello", "100", "abc"]
for inp in inputs:
    result = parse_number(inp)
    print(f"  parse('{inp}') → {result}  ({type(result).__name__})")

# --- else and finally ---
def read_list_item(lst, index):
    try:
        value = lst[index]
    except IndexError:
        print(f"  Index {index} out of range!")
    else:
        print(f"  Found: {value}")
    finally:
        print(f"  (attempted index {index})")

nums = [10, 20, 30]
read_list_item(nums, 1)
read_list_item(nums, 9)`,

        lambda: `# Lambda functions — small, anonymous functions defined in one line.
# Best used when you need a short function in just one place.

# Regular function vs lambda
def square(x):
    return x ** 2

square_lambda = lambda x: x ** 2

print(square(5))          # 25
print(square_lambda(5))   # 25  (same result)

# --- Lambda with map() ---
numbers = [1, 2, 3, 4, 5]
cubed = list(map(lambda x: x ** 3, numbers))
print("Cubed:", cubed)    # [1, 8, 27, 64, 125]

# --- Lambda with filter() ---
evens = list(filter(lambda x: x % 2 == 0, range(1, 21)))
print("Evens:", evens)    # [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]

# --- Lambda with sorted() ---
students = [("Alice", 88), ("Carol", 95), ("Bob", 72), ("David", 91)]
by_score = sorted(students, key=lambda s: s[1], reverse=True)
print("\\nRanking:")
for rank, (name, score) in enumerate(by_score, 1):
    print(f"  #{rank} {name}: {score}")

# --- Lambda with multiple parameters ---
multiply = lambda a, b: a * b
print("\\n3 × 7 =", multiply(3, 7))`,

        zip_enum: `# zip() pairs up items from two lists.
# enumerate() gives you (index, value) pairs as you loop.

# --- enumerate() ---
fruits = ["apple", "banana", "cherry", "date"]

print("Shopping list:")
for index, fruit in enumerate(fruits, start=1):
    print(f"  {index}. {fruit}")

# --- zip() ---
names  = ["Alice", "Bob", "Carol"]
scores = [88, 92, 79]
grades = ["B", "A", "C"]

print("\\nReport:")
print(f"{'Name':<10} {'Score':>5} {'Grade':>6}")
print("-" * 25)
for name, score, grade in zip(names, scores, grades):
    print(f"{name:<10} {score:>5} {grade:>6}")

# --- zip() to build a dict ---
keys   = ["name", "age", "city"]
values = ["Jonathan", 21, "Austin"]
info   = dict(zip(keys, values))
print("\\nDictionary:", info)

# --- Unzip with zip(*...) ---
pairs  = [(1, "a"), (2, "b"), (3, "c")]
nums, letters = zip(*pairs)
print("Unzipped nums:   ", nums)
print("Unzipped letters:", letters)`,

        sorting: `# Python's sorted() and .sort() are powerful.
# The 'key' parameter lets you sort by anything you choose.

# --- Basic sort ---
nums = [5, 2, 8, 1, 9, 3, 7, 4, 6]
print("Ascending: ", sorted(nums))
print("Descending:", sorted(nums, reverse=True))

# --- Sort strings ---
words = ["banana", "Apple", "cherry", "date", "Elderberry"]
print("Alphabetical:     ", sorted(words))
print("Case-insensitive: ", sorted(words, key=str.lower))
print("By length:        ", sorted(words, key=len))

# --- Sort a list of dicts ---
students = [
    {"name": "Carol",  "gpa": 3.5, "year": 2},
    {"name": "Alice",  "gpa": 3.9, "year": 1},
    {"name": "Bob",    "gpa": 3.2, "year": 3},
    {"name": "David",  "gpa": 3.9, "year": 2},
]

# Sort by GPA descending, then name ascending
by_gpa = sorted(students, key=lambda s: (-s["gpa"], s["name"]))
print("\\nBy GPA (desc), then name (asc):")
for s in by_gpa:
    print(f"  {s['name']:<8}  GPA: {s['gpa']}  Year: {s['year']}")`,

        recursion: `# Recursion — a function that calls itself!
# Every recursive function needs a BASE CASE to stop.

# --- Classic: Factorial ---
def factorial(n):
    if n <= 1: return 1          # base case
    return n * factorial(n - 1)  # recursive case

# --- Fibonacci ---
def fib(n, memo={}):
    if n <= 1: return n          # base case
    if n in memo: return memo[n] # cached result (memoization)
    memo[n] = fib(n-1) + fib(n-2)
    return memo[n]

# --- Sum of nested list ---
def flatten_sum(lst):
    total = 0
    for item in lst:
        if isinstance(item, list):
            total += flatten_sum(item)  # recurse into sublists
        else:
            total += item
    return total

print("Factorials:")
for i in range(1, 11):
    print(f"  {i:2d}! = {factorial(i):,}")

print("\\nFibonacci (first 15):")
print(" ".join(str(fib(i)) for i in range(15)))

nested = [1, [2, 3], [4, [5, 6]], 7]
print(f"\\nNested sum of {nested}:")
print(f"  = {flatten_sum(nested)}")`,

        unpacking: `# Tuple unpacking lets you assign multiple variables at once.
# *args collects extra positional arguments into a list.

# --- Basic unpacking ---
point = (10, 20)
x, y = point
print(f"x={x}, y={y}")

# --- Swap two variables (Python trick!) ---
a, b = 5, 10
print(f"Before: a={a}, b={b}")
a, b = b, a
print(f"After:  a={a}, b={b}")

# --- Extended unpacking with * ---
first, *middle, last = [1, 2, 3, 4, 5, 6]
print(f"\\nfirst={first}, middle={middle}, last={last}")

# --- Unpack in a loop ---
students = [("Alice", 88, "A"), ("Bob", 72, "C"), ("Carol", 95, "A")]
for name, score, grade in students:
    print(f"  {name}: {score} ({grade})")

# --- *args in functions ---
def total(*prices):
    print(f"Prices: {prices}")
    return sum(prices)

print("\\nTotal:", total(9.99, 14.50, 4.00))
print("Total:", total(5.00, 10.00))

# --- **kwargs ---
def describe(**info):
    for key, val in info.items():
        print(f"  {key}: {val}")

print("\\nProfile:")
describe(name="Jonathan", age=21, major="AI Engineering")`,

        comprehensions: `# Beyond list comprehensions — you can also make
# sets and dictionaries the same compact way!

# --- List comprehension (review) ---
squares = [x**2 for x in range(1, 11)]
print("Squares:", squares)

# --- Set comprehension --- (unique values only)
words = ["hello", "world", "hello", "python", "world", "code"]
unique_lengths = {len(w) for w in words}
print("Unique word lengths:", sorted(unique_lengths))

first_letters = {w[0].upper() for w in words}
print("First letters:", sorted(first_letters))

# --- Dictionary comprehension ---
names  = ["Alice", "Bob", "Carol", "David"]
scores = [88, 72, 95, 61]

grade_book = {name: score for name, score in zip(names, scores)}
print("\\nGrade book:", grade_book)

# Filter: only students who passed
passing = {name: score for name, score in grade_book.items() if score >= 70}
print("Passing:   ", passing)

# Transform: add letter grade
def letter(s): return "A" if s>=90 else "B" if s>=80 else "C" if s>=70 else "F"
with_grades = {name: (score, letter(score)) for name, score in grade_book.items()}
print("\\nWith grades:")
for name, (score, grade) in with_grades.items():
    print(f"  {name:<8}: {score}  ({grade})")`,

        password_generator: `# Generate a random secure password and check its strength.
import random, string

length = 12
chars = string.ascii_letters + string.digits + "!@#$%^&*"
password = "".join(random.choice(chars) for _ in range(length))

print("Generated password:", password)

categories = sum([
    any(c.islower() for c in password),
    any(c.isupper() for c in password),
    any(c.isdigit() for c in password),
    any(c in "!@#$%^&*" for c in password)
])
strength = ["Weak", "Fair", "Good", "Strong", "Excellent"][categories]
print("Strength:", strength)`,

        datetime_basics: `# Working with dates and times in Python.
import datetime

now = datetime.datetime.now()
print("Now:", now)
print("Date only:", now.date())
print("Time only:", now.time())
print("Formatted:", now.strftime("%A, %B %d, %Y"))
print("ISO format:", now.isoformat())

# Date arithmetic
birthday = datetime.date(2000, 5, 15)
today = datetime.date.today()
age = today.year - birthday.year - ((today.month, today.day) < (birthday.month, birthday.day))
print(f"Age: {age} years")`,

        api_simulation: `# Simulating API data fetching and processing.
import json

cities = [
    {"name": "New York", "temp": 72, "condition": "Sunny"},
    {"name": "London", "temp": 58, "condition": "Rainy"},
    {"name": "Tokyo", "temp": 65, "condition": "Cloudy"},
]

# Simulate fetching data
for city in cities:
    print(f"{city['name']}: {city['temp']}°F, {city['condition']}")

# Filter warm cities
warm = [c for c in cities if c['temp'] > 60]
print(f"\\nWarm cities ({len(warm)}): {[c['name'] for c in warm]}")

# Convert to JSON (as if sending to a web API)
json_data = json.dumps(cities, indent=2)
print("\\nJSON output:")
print(json_data)`,

        sets_math: `# Set operations for math and data analysis.
a = {1, 2, 3, 4, 5}
b = {4, 5, 6, 7, 8}

print("Set A:", a)
print("Set B:", b)
print("Union (A | B):", a | b)
print("Intersection (A & B):", a & b)
print("Difference (A - B):", a - b)
print("Symmetric diff (A ^ B):", a ^ b)
print("Is A subset of Union?", a.issubset(a | b))`,

        generators: `# Generator functions use yield instead of return.
# They produce values one at a time, saving memory.

def count_up_to(n):
    count = 1
    while count <= n:
        yield count
        count += 1

counter = count_up_to(5)
print("Generator values:")
for num in counter:
    print(f"  {num}")

# Generator expression (like list comprehension but lazy)
squares = (x**2 for x in range(1, 6))
print("Squares:", list(squares))

# Fibonacci generator
def fibonacci(n):
    a, b = 0, 1
    for _ in range(n):
        yield a
        a, b = b, a + b

print("Fibonacci:", list(fibonacci(10)))`,

        itertools: `# itertools and Counter for powerful data handling.
import itertools, collections

# Count from 100 by 5s
print("Counting:", list(itertools.islice(itertools.count(100, 5), 5)))

# All pairs from a list
friends = ["Alice", "Bob", "Carol"]
pairs = list(itertools.combinations(friends, 2))
print("Pairs:", pairs)

# Cycle through colors
colors = ["red", "green", "blue"]
cycled = list(itertools.islice(itertools.cycle(colors), 7))
print("Cycled:", cycled)

# Count word frequencies
words = ["apple", "banana", "apple", "cherry", "banana", "apple"]
counts = collections.Counter(words)
print("Word counts:", dict(counts))
print("Most common:", counts.most_common(2))`,

      };

      const breakdowns = {
        hello: `<strong>What it does:</strong> Prints greetings and values using <code>print()</code>.<br>
<strong>Try it:</strong> Change the name or number and run again.<br>
<strong>Concept:</strong> <code>print()</code> — your most-used Python function.`,

        loop: `<strong>What it does:</strong> Shows three different ways to use <code>for</code> loops with <code>range()</code>.<br>
<strong>Try it:</strong> Change the numbers in <code>range()</code> to count differently.<br>
<strong>Concept:</strong> <code>for</code> loops, <code>range(start, stop, step)</code>.`,

        list_sum: `<strong>What it does:</strong> Analyzes a list of scores using built-in functions.<br>
<strong>Try it:</strong> Change the numbers in <code>scores</code> and see all stats update.<br>
<strong>Concept:</strong> Lists, <code>sum()</code>, <code>max()</code>, <code>min()</code>, <code>len()</code>, list comprehension.`,

        string_reverse: `<strong>What it does:</strong> Reverses strings and checks for palindromes.<br>
<strong>Try it:</strong> Add your own words to the <code>words</code> list.<br>
<strong>Concept:</strong> String slicing (<code>[::-1]</code>), <code>join()</code>, <code>split()</code>.`,

        factorial: `<strong>What it does:</strong> Calculates factorials for 1 through 10 using recursion.<br>
<strong>Try it:</strong> Change the range to go higher.<br>
<strong>Concept:</strong> Recursion — functions that call themselves, with a base case.`,

        fstring: `<strong>What it does:</strong> Shows all the ways f-strings can format numbers, text, and alignment.<br>
<strong>Try it:</strong> Change <code>name</code>, <code>gpa</code>, or <code>price</code> and watch the output update.<br>
<strong>Concept:</strong> F-strings, format specifiers (<code>:.2f</code>, <code>:>20</code>, <code>:.1%</code>).`,

        dict_basics: `<strong>What it does:</strong> Creates, accesses, updates, and loops through a dictionary.<br>
<strong>Try it:</strong> Add a new key-value pair like <code>person["hobby"] = "coding"</code>.<br>
<strong>Concept:</strong> Dictionaries, <code>.get()</code>, <code>.items()</code>, <code>.pop()</code>.`,

        list_comp: `<strong>What it does:</strong> Demonstrates list, dict, and filter comprehensions side by side.<br>
<strong>Try it:</strong> Change the filter condition (e.g. <code>if n % 3 == 0</code> for multiples of 3).<br>
<strong>Concept:</strong> List comprehensions — compact, Pythonic loops.`,

        while_loop: `<strong>What it does:</strong> Shows counting, an ATM simulation, and searching with <code>while</code>.<br>
<strong>Try it:</strong> Change the withdrawal amounts in the list.<br>
<strong>Concept:</strong> <code>while</code> loops, <code>break</code>, infinite loop with exit condition.`,

        functions: `<strong>What it does:</strong> Defines functions with parameters, default values, and <code>*args</code>.<br>
<strong>Try it:</strong> Call <code>greet()</code> with your own name, or change the power base.<br>
<strong>Concept:</strong> Functions, <code>def</code>, <code>return</code>, default parameters, <code>*args</code>.`,

        classes: `<strong>What it does:</strong> Builds a <code>Dog</code> class with attributes and methods, then creates two instances.<br>
<strong>Try it:</strong> Create a third dog or add a new method like <code>birthday(self)</code>.<br>
<strong>Concept:</strong> Classes, <code>__init__</code>, <code>self</code>, instance methods, <code>__str__</code>.`,

        error_handling: `<strong>What it does:</strong> Shows <code>try/except</code> with multiple error types, plus <code>else</code> and <code>finally</code>.<br>
<strong>Try it:</strong> Add a new string to <code>inputs</code> like <code>"999"</code> or <code>"hello"</code>.<br>
<strong>Concept:</strong> <code>try/except/else/finally</code>, <code>ZeroDivisionError</code>, <code>ValueError</code>, <code>IndexError</code>.`,

        lambda: `<strong>What it does:</strong> Shows how lambdas replace named functions in <code>map()</code>, <code>filter()</code>, and <code>sorted()</code>.<br>
<strong>Try it:</strong> Change the lambda in <code>sorted()</code> to sort by name instead of score.<br>
<strong>Concept:</strong> <code>lambda</code> functions, <code>map()</code>, <code>filter()</code>, <code>sorted(key=...)</code>.`,

        zip_enum: `<strong>What it does:</strong> Shows all major uses of <code>zip()</code> and <code>enumerate()</code> including unzipping.<br>
<strong>Try it:</strong> Add a fourth name/score/grade trio to each list.<br>
<strong>Concept:</strong> <code>zip()</code>, <code>enumerate()</code>, <code>zip(*...)</code> for unzipping.`,

        sorting: `<strong>What it does:</strong> Sorts numbers, strings, and dicts using <code>key=</code> and multi-criteria sorting.<br>
<strong>Try it:</strong> Change the sort key to <code>lambda s: s["year"]</code> to sort by year.<br>
<strong>Concept:</strong> <code>sorted()</code>, <code>key=</code> parameter, <code>lambda</code>, multi-key sort with tuples.`,

        recursion: `<strong>What it does:</strong> Shows three recursive patterns: factorial, Fibonacci with memoization, and nested list sum.<br>
<strong>Try it:</strong> Call <code>fib(30)</code> — notice how fast memoization makes it!<br>
<strong>Concept:</strong> Recursion, base case, memoization, <code>isinstance()</code>.`,

        unpacking: `<strong>What it does:</strong> Demonstrates tuple unpacking, star unpacking, and <code>**kwargs</code>.<br>
<strong>Try it:</strong> Try <code>first, *rest = [1,2,3,4,5]</code> to see what <code>rest</code> holds.<br>
<strong>Concept:</strong> Tuple unpacking, <code>*args</code>, <code>**kwargs</code>, multiple assignment.`,

        comprehensions: `<strong>What it does:</strong> Shows list, set, and dictionary comprehensions side-by-side with real examples.<br>
<strong>Try it:</strong> Add your own name/score pair to the lists and see the grade book update.<br>
<strong>Concept:</strong> List/set/dict comprehensions, filtering with <code>if</code> inside a comprehension.`,

        password_generator: `<strong>What it does:</strong> Creates random secure passwords and checks their strength.<br>
<strong>Try it:</strong> Change <code>length</code> to 8 or 32, or set <code>use_symbols = False</code>.<br>
<strong>Concept:</strong> <code>random.choice()</code>, <code>string.ascii_letters</code>, loops, <code>any()</code>.`,

        datetime_basics: `<strong>What it does:</strong> Gets the current date/time and formats it in multiple ways.<br>
<strong>Try it:</strong> Change the format string to show month name or 12-hour time.<br>
<strong>Concept:</strong> <code>datetime</code> module, <code>strftime()</code>, date arithmetic.`,

        api_simulation: `<strong>What it does:</strong> Simulates fetching and processing API data (like from a weather service).<br>
<strong>Try it:</strong> Change the city data or add a new city!<br>
<strong>Concept:</strong> Dictionaries, <code>json.dumps()</code>, data transformation, filtering.`,

        sets_math: `<strong>What it does:</strong> Demonstrates set union, intersection, difference, and symmetric difference.<br>
<strong>Try it:</strong> Change the class rosters and see which students are in both classes.<br>
<strong>Concept:</strong> Sets, <code>| & - ^</code> operators, <code>issubset()</code>.`,

        generators: `<strong>What it does:</strong> Creates memory-efficient sequences using <code>yield</code> instead of storing everything in a list.<br>
<strong>Try it:</strong> Change <code>count_to</code> to 1,000,000 — it still uses almost no memory!<br>
<strong>Concept:</strong> <code>yield</code>, generator functions, <code>next()</code>, memory efficiency.`,

        itertools: `<strong>What it does:</strong> Uses <code>itertools</code> and <code>collections.Counter</code> for powerful one-liners.<br>
<strong>Try it:</strong> Change the card hands and see the permutations count!<br>
<strong>Concept:</strong> <code>itertools.permutations</code>, <code>combinations</code>, <code>Counter</code>, <code>most_common()</code>.`
      };

      const val = document.getElementById('samples').value;
      document.getElementById('codeInput').value = samples[val] || "";
      previewCode.textContent = document.getElementById('codeInput').value;
      Prism.highlightElement(previewCode);
      const explainBox = document.getElementById('sampleExplain');
      if (val && breakdowns[val]) {
        explainBox.style.display = "";
        explainBox.innerHTML = breakdowns[val];
      } else {
        explainBox.style.display = "none";
        explainBox.textContent = "";
      }
    }

    const codeInput = document.getElementById('codeInput');
    const previewCode = document.querySelector('#previewCode code');

    codeInput.addEventListener('input', function() {
      previewCode.textContent = codeInput.value;
      Prism.highlightElement(previewCode);
    });

    previewCode.textContent = codeInput.value;
    Prism.highlightElement(previewCode);

    function copyCode() {
      let code = document.getElementById('codeInput').value;
      navigator.clipboard.writeText(code).then(function() {
        alert('Code copied!');
      });
    }

    function shareCode() {
      const code = codeInput.value;
      const encoded = btoa(unescape(encodeURIComponent(code)));
      const url = location.origin + location.pathname + '#code=' + encoded;
      navigator.clipboard.writeText(url).then(function() {
        const btn = document.getElementById('shareBtn');
        const original = btn.textContent;
        btn.textContent = 'Copied! ✅';
        setTimeout(function() { btn.textContent = original; }, 2000);
      });
    }

    function loadFromHash() {
      const hash = location.hash;
      if (hash.startsWith('#code=')) {
        try {
          const encoded = hash.slice(6);
          const code = decodeURIComponent(escape(atob(encoded)));
          codeInput.value = code;
          previewCode.textContent = code;
          Prism.highlightElement(previewCode);
          startCoding();
        } catch(e) {}
      }
    }

    loadFromHash();

    function clearOutput() {
      document.getElementById('pyOutput').textContent = "";
      const stepBox = document.getElementById('stepExplain');
      stepBox.style.display = 'none';
      stepBox.innerHTML = '';
    }

    function loadErrorExample(code) {
      codeInput.value = code;
      previewCode.textContent = code;
      Prism.highlightElement(previewCode);
      document.getElementById('pyOutput').textContent = "";
      var stepBox = document.getElementById('stepExplain');
      if (stepBox) { stepBox.style.display = 'none'; stepBox.innerHTML = ''; }
      showSection('sec-editor');
    }

    function loadExampleFromPre(id) {
      var code = document.getElementById(id).textContent;
      codeInput.value = code;
      previewCode.textContent = code;
      Prism.highlightElement(previewCode);
      document.getElementById('pyOutput').textContent = "";
      var stepBox = document.getElementById('stepExplain');
      if (stepBox) { stepBox.style.display = 'none'; stepBox.innerHTML = ''; }
      showSection('sec-editor');
    }

    function toggleExample(id) {
      var ex = document.getElementById(id);
      if (ex.style.display === "none") {
        ex.style.display = "block";
      } else {
        ex.style.display = "none";
      }
    }

    function showWebTab(tab) {
      var tabs = ["html", "css", "js", "py"];
      tabs.forEach(function(t) {
        document.getElementById("wtab-content-" + t).style.display = (t === tab) ? "" : "none";
        var btn = document.getElementById("wtab-" + t);
        btn.style.opacity = (t === tab) ? "1" : "0.55";
        btn.style.outline = (t === tab) ? "3px solid #fff" : "none";
      });
    }
    showWebTab("html");

    var WEB_PREVIEWS = {
      'html-skeleton': '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><title>My Page</title><style>body{font-family:Arial,sans-serif;padding:30px;background:#f4f8fd;}h1{color:#0537cd;}p{color:#333;line-height:1.6;}</style></head><body><h1>Hello, World!</h1><p>This is my first web page.</p><p>Built with just HTML — no installations required!</p><hr><p><em>Edit the code and watch it change!</em></p></body></html>',

      'html-lists': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:24px;background:#fff8f0;}h2{color:#e8780a;}li{margin:6px 0;line-height:1.5;}</style></head><body><h2>Unordered List (bullets)</h2><ul><li>Apples</li><li>Bananas</li><li>Oranges</li></ul><h2>Ordered List (numbers)</h2><ol><li>Wake up</li><li>Eat breakfast</li><li>Code!</li></ol><h2>Nested Lists</h2><ul><li>Fruits<ul><li>Apple</li><li>Mango</li></ul></li><li>Veggies<ul><li>Broccoli</li></ul></li></ul></body></html>',

      'html-forms': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:24px;background:#fff8f0;max-width:420px;}h2{color:#e8780a;}label{display:block;margin-top:14px;font-weight:bold;color:#555;}input,select,textarea{width:100%;padding:7px 10px;margin-top:4px;border:1px solid #ccc;border-radius:5px;box-sizing:border-box;font-size:0.97em;}button{margin-top:16px;background:#e8780a;color:#fff;padding:9px 24px;border:none;border-radius:5px;cursor:pointer;font-size:1em;}button:hover{background:#c0600a;}</style></head><body><h2>Contact Form</h2><form onsubmit="event.preventDefault();alert(\'Form submitted!\')"><label for="n">Your name:</label><input type="text" id="n" placeholder="Jonathan"><label for="a">Age:</label><input type="number" id="a" min="1"><label for="c">Favorite color:</label><select id="c"><option>Blue</option><option>Red</option><option>Green</option></select><label for="m">Message:</label><textarea id="m" rows="3" placeholder="Write something..."></textarea><button type="submit">Send</button></form></body></html>',

      'css-basics': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:20px;background:#f4f8fd;}h1{color:navy;font-size:2em;text-align:center;margin-bottom:20px;}.card{background:#fff;border-radius:8px;padding:16px;box-shadow:0 2px 6px rgba(0,0,0,0.15);margin:16px 0;line-height:1.6;}#hero{background:#08036a;color:white;padding:20px;border-radius:8px;text-align:center;margin-top:20px;}#hero p{margin:4px 0;}</style></head><body><h1>CSS in Action</h1><div class="card"><p><strong>.card</strong> — white background, rounded corners, drop shadow.</p><p>Works on any element with <code>class="card"</code>.</p></div><div class="card"><p>You can have <em>multiple</em> elements sharing the same class!</p></div><div id="hero"><p><strong>#hero</strong> — only one element gets this id.</p><p>Dark navy background, white text, centered.</p></div></body></html>',

      'css-flexbox': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:20px;background:#f4f8fd;}h2{color:#1565c0;text-align:center;}.container{display:flex;justify-content:center;align-items:center;gap:16px;flex-wrap:wrap;background:#e8eaf6;padding:24px;border-radius:10px;margin:16px 0;}.box{width:80px;height:80px;display:flex;align-items:center;justify-content:center;border-radius:8px;color:#fff;font-weight:bold;font-size:1.2em;}p{text-align:center;color:#555;font-size:0.95em;}</style></head><body><h2>Flexbox Layout</h2><div class="container"><div class="box" style="background:#e63946;">A</div><div class="box" style="background:#2a9d8f;">B</div><div class="box" style="background:#e9c46a;color:#333;">C</div><div class="box" style="background:#264653;">D</div><div class="box" style="background:#6a4c93;">E</div></div><p>All 5 boxes are centered using <code>display:flex; justify-content:center;</code></p></body></html>',

      'js-variables': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:20px;background:#fffde7;}h2{color:#b8860b;}.box{background:#fff;border:1px solid #e6a817;border-radius:6px;padding:12px 16px;margin:10px 0;font-family:monospace;font-size:0.97em;line-height:1.7;}span.label{font-weight:bold;color:#b8860b;display:inline-block;width:130px;}</style></head><body><h2>JS Variables &amp; Data Types</h2><div class="box"><span class="label">string:</span> <span id="s"></span><br><span class="label">number:</span> <span id="n"></span><br><span class="label">boolean:</span> <span id="b"></span><br><span class="label">null:</span> <span id="nl"></span><br><span class="label">undefined:</span> <span id="u"></span></div><div class="box"><span class="label">Array:</span> <span id="arr"></span><br><span class="label">arr[0]:</span> <span id="arr0"></span></div><div class="box"><span class="label">Object:</span> <span id="obj"></span><br><span class="label">.name:</span> <span id="oname"></span> &nbsp; <span class="label">.age:</span> <span id="oage"></span></div><script>let name="Jonathan";const PI=3.14159;let active=true;let score=null;let x;document.getElementById("s").textContent=\'"\'+name+\'"  (string)\';document.getElementById("n").textContent=PI+"  (number)";document.getElementById("b").textContent=active+"  (boolean)";document.getElementById("nl").textContent=score+"  (null)";document.getElementById("u").textContent=x+"  (undefined)";let colors=["red","green","blue"];document.getElementById("arr").textContent=JSON.stringify(colors);document.getElementById("arr0").textContent=\'"\'+colors[0]+\'"\';let person={name:"Jonathan",age:22};document.getElementById("obj").textContent=JSON.stringify(person);document.getElementById("oname").textContent=\'"\'+person.name+\'"\';document.getElementById("oage").textContent=person.age;<\/script></body></html>',

      'js-dom': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:20px;background:#fffde7;}h1{color:#b8860b;transition:all 0.3s;}button{background:#e6a817;border:none;padding:8px 16px;border-radius:5px;cursor:pointer;font-size:0.95em;margin:5px 4px;color:#1a1a00;}button:hover{background:#c08010;}.hint{font-size:0.88em;color:#888;margin-top:10px;}</style></head><body><h1 id="myTitle">Original Heading</h1><p>Click the buttons to change the DOM live:</p><button onclick="document.getElementById(\'myTitle\').textContent=\'Updated by JavaScript!\'">Change Text</button><button onclick="document.getElementById(\'myTitle\').style.color=\'#e63946\'">Red Color</button><button onclick="document.getElementById(\'myTitle\').style.color=\'#2a9d8f\'">Teal Color</button><button onclick="document.getElementById(\'myTitle\').style.fontSize=\'2.5em\'">Bigger Font</button><button onclick="var el=document.getElementById(\'myTitle\');el.textContent=\'Original Heading\';el.style.color=\'\';el.style.fontSize=\'\';">Reset</button><p class="hint">Each button runs one line of JavaScript to change the element.</p></body></html>',

      'js-events': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:24px;background:#fffde7;text-align:center;}h2{color:#b8860b;}#count{font-size:3.5em;font-weight:bold;color:#e6a817;margin:16px 0;transition:transform 0.1s;}button{background:#e6a817;border:none;padding:10px 26px;border-radius:6px;cursor:pointer;font-size:1.05em;margin:5px;color:#1a1a00;}button:hover{background:#c08010;}#msg{margin-top:12px;color:#888;font-size:0.95em;}</style></head><body><h2>Click Counter</h2><div id="count">0</div><p style="color:#555;">clicks so far</p><button id="clickBtn">Click me!</button><button onclick="n=0;document.getElementById(\'count\').textContent=0;document.getElementById(\'msg\').textContent=\'Reset!\'" style="background:#888;color:#fff;">Reset</button><p id="msg">Try clicking fast!</p><script>let n=0;document.getElementById("clickBtn").addEventListener("click",function(){n++;var el=document.getElementById("count");el.textContent=n;el.style.transform="scale(1.2)";setTimeout(function(){el.style.transform="";},100);if(n===10)document.getElementById("msg").textContent="10 clicks! Keep going!";if(n===50)document.getElementById("msg").textContent="50?! You\'re on fire!";});<\/script></body></html>',

      'js-flow': '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{font-family:Arial,sans-serif;padding:20px;background:#fffde7;}h2{color:#b8860b;}.box{background:#fff;border:1px solid #e6a817;border-radius:6px;padding:12px 16px;margin:10px 0;font-family:monospace;line-height:1.8;}span.label{font-weight:bold;color:#b8860b;}</style></head><body><h2>Control Flow &amp; Functions</h2><div class="box"><span class="label">if/else:</span><br><span id="grade"></span></div><div class="box"><span class="label">for loop (i = 0..4):</span><br><span id="loop"></span></div><div class="box"><span class="label">function add(3, 4):</span> <span id="addR"></span><br><span class="label">multiply(3, 4):</span> <span id="mulR"></span></div><script>let score=85;let grade=score>=90?"A — Excellent":score>=80?"B — Good":score>=70?"C — OK":"Below C";document.getElementById("grade").textContent="score = "+score+" → Grade: "+grade;let cells=[];for(let i=0;i<5;i++)cells.push(\'<span style="background:#e6a817;color:#1a1a00;padding:2px 8px;border-radius:3px;margin:2px;">i = \'+i+"<\/span>");document.getElementById("loop").innerHTML=cells.join(" ");function add(a,b){return a+b;}const multiply=(a,b)=>a*b;document.getElementById("addR").textContent=add(3,4);document.getElementById("mulR").textContent=multiply(3,4);<\/script></body></html>'
    };

    function showLivePreview(key, title) {
      var html = WEB_PREVIEWS[key];
      if (!html) return;
      var blob = new Blob([html], { type: 'text/html' });
      var url = URL.createObjectURL(blob);
      var frame = document.getElementById('livePreviewFrame');
      frame.src = url;
      document.getElementById('livePreviewTitle').textContent = title || 'Live Preview';
      document.getElementById('livePreviewModal').classList.add('open');
      document.body.style.overflow = 'hidden';
    }

    function closeLivePreview() {
      document.getElementById('livePreviewModal').classList.remove('open');
      document.body.style.overflow = '';
      var frame = document.getElementById('livePreviewFrame');
      var old = frame.src;
      frame.src = '';
      try { URL.revokeObjectURL(old); } catch(e) {}
    }

    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') closeLivePreview();
    });

    let pyodideReady = false;
    let pyodide = null;
    let runBtn = document.getElementById('runBtn');
    let pyOutput = document.getElementById('pyOutput');

    async function initPyodideAndSetup() {
      runBtn.disabled = true;
      runBtn.textContent = "Loading Python...";
      pyOutput.textContent = "Loading Python (Pyodide)...";
      pyodide = await loadPyodide();
      await pyodide.runPythonAsync(`
import builtins
from js import prompt as _js_prompt
def _input_override(msg=""):
    result = _js_prompt(str(msg))
    if result is None:
        return ""
    return str(result)
builtins.input = _input_override
`);
      pyodideReady = true;
      runBtn.disabled = false;
      runBtn.textContent = "Run 🟢";
      pyOutput.textContent = '';
    }

    initPyodideAndSetup();

    function explainSteps(code) {
      const lines = code.split('\n');
      const steps = [];
      let stepNum = 0;

      function addStep(desc) {
        stepNum++;
        steps.push(`<div class="step-line"><span class="step-num">${stepNum}</span><span class="step-desc">${desc}</span></div>`);
      }

      for (let raw of lines) {
        const line = raw.trim();
        if (!line || line.startsWith('#')) continue;

        if (line.startsWith('import ') || line.startsWith('from ')) {
          const mod = line.replace(/^import\s+|^from\s+/, '').split(/[,\s]/)[0];
          addStep(`Import the <code>${mod}</code> module so we can use its features.`);
        }
        else if (/^([A-Za-z_]\w*)\s*=/.test(line)) {
          const name = line.match(/^([A-Za-z_]\w*)\s*=/)[1];
          addStep(`Create a variable named <code>${name}</code> and store a value in it.`);
        }
        else if (line.startsWith('def ')) {
          const name = line.match(/def\s+(\w+)/)?.[1] || 'function';
          addStep(`Define a reusable function called <code>${name}()</code> that we can call later.`);
        }
        else if (line.startsWith('class ')) {
          const name = line.match(/class\s+(\w+)/)?.[1] || 'class';
          addStep(`Create a blueprint (class) named <code>${name}</code> for making objects.`);
        }
        else if (line.startsWith('for ')) {
          addStep(`Start a <code>for</code> loop to repeat actions for each item in a sequence.`);
        }
        else if (line.startsWith('while ')) {
          addStep(`Start a <code>while</code> loop that keeps running as long as a condition is true.`);
        }
        else if (line.startsWith('if ') || line.startsWith('elif ')) {
          addStep(`Check a condition with <code>if</code> to decide which code block to run.`);
        }
        else if (line.startsWith('else:')) {
          addStep(`If none of the above conditions matched, run this <code>else</code> block instead.`);
        }
        else if (line.startsWith('try:')) {
          addStep(`Wrap the next code in <code>try</code> to catch any errors that might happen.`);
        }
        else if (line.startsWith('except ')) {
          addStep(`If an error occurs, handle it gracefully in this <code>except</code> block.`);
        }
        else if (line.startsWith('return ')) {
          addStep(`Send a result back from the function to wherever it was called.`);
        }
        else if (line.startsWith('print(')) {
          const inner = line.slice(6, -1);
          if (inner.includes('input(')) {
            addStep(`Show a prompt to the user and wait for them to type something.`);
          } else if (inner.includes('f"') || inner.includes("f'")) {
            addStep(`Display output on screen, using an f-string to insert values into the message.`);
          } else if (inner.includes('+') || inner.includes(',')) {
            addStep(`Display multiple pieces of text combined together on the screen.`);
          } else {
            addStep(`Print a message or value to the screen so we can see the result.`);
          }
        }
        else if (line.startsWith('input(')) {
          addStep(`Ask the user to type something and capture what they enter.`);
        }
        else if (line.includes('.append(')) {
          addStep(`Add a new item to the end of a list.`);
        }
        else if (line.includes('.get(')) {
          addStep(`Safely fetch a value from a dictionary, using a fallback if the key is missing.`);
        }
        else if (line.includes('.split(')) {
          addStep(`Break a string into a list of pieces at a certain separator.`);
        }
        else if (line.includes('.join(')) {
          addStep(`Combine a list of strings into one string with a separator between them.`);
        }
        else if (line.includes('.sort(') || line.includes('sorted(')) {
          addStep(`Arrange items in a specific order (e.g., alphabetical or numerical).`);
        }
        else if (line.includes('random.')) {
          addStep(`Use the random module to pick or generate something unpredictably.`);
        }
        else if (line.includes('open(')) {
          addStep(`Open a file so we can read from it or write to it.`);
        }
        else if (line.includes('json.')) {
          addStep(`Convert data to or from JSON format (common for web APIs).`);
        }
        else if (line.includes('lambda')) {
          addStep(`Create a quick, unnamed function for a one-time use.`);
        }
        else if (line.includes('yield')) {
          addStep(`Pause the function and return one value at a time (generator pattern).`);
        }
        else if (line.includes('zip(')) {
          addStep(`Combine two or more lists side-by-side so we can loop through them together.`);
        }
        else if (line.includes('enumerate(')) {
          addStep(`Loop through a list while also keeping track of the position number.`);
        }
        else if (line.includes('Counter(')) {
          addStep(`Count how many times each item appears in a list.`);
        }
        else if (line.includes('itertools.')) {
          addStep(`Use itertools to create efficient combinations, permutations, or cycles.`);
        }
        else if (line.includes('datetime.')) {
          addStep(`Work with dates and times using Python's datetime tools.`);
        }
      }

      const box = document.getElementById('stepExplain');
      if (steps.length > 0) {
        box.style.display = '';
        box.innerHTML = '<h4>What the code is doing, step by step:</h4>' + steps.join('');
      } else {
        box.style.display = 'none';
        box.innerHTML = '';
      }
    }

    async function runPython() {
      if (!pyodideReady) return;
      runBtn.disabled = true;
      runBtn.textContent = "Running...";
      pyOutput.textContent = "";
      const code = codeInput.value;
      explainSteps(code);
      try {
        await pyodide.runPythonAsync(`
import sys
import io
import traceback
_stdout = sys.stdout
_stderr = sys.stderr
sys.stdout = io.StringIO()
sys.stderr = io.StringIO()
__result__ = ''
__err__ = ''
try:
${code.split('\n').map(line => '    ' + line).join('\n')}
except SystemExit:
    pass
except BaseException:
    __err__ = traceback.format_exc()
finally:
    __result__ = sys.stdout.getvalue()
    if not __err__:
        __err__ = sys.stderr.getvalue()
    sys.stdout = _stdout
    sys.stderr = _stderr
`);
        let output = pyodide.globals.get('__result__') || '';
        let error = pyodide.globals.get('__err__') || '';
        pyOutput.textContent = output + (error ? "\nError:\n" + error : "");
      } catch (err) {
        pyOutput.textContent = "Error:\n" + err;
      } finally {
        runBtn.disabled = false;
        runBtn.textContent = "Run 🟢";
      }
    }

      /* ── Auth ── */
      var authMode = 'login';
      function openAuth(mode) {
        authMode = mode;
        document.getElementById('authTitle').textContent = mode === 'login' ? 'Log in' : 'Sign up';
        document.getElementById('authBtn').textContent = mode === 'login' ? 'Log in' : 'Sign up';
        document.getElementById('authError').textContent = '';
        document.getElementById('authEmail').value = '';
        document.getElementById('authPass').value = '';
        var toggle = document.getElementById('authToggle');
        toggle.innerHTML = '';
        var label = document.createTextNode(mode === 'login' ? 'No account? ' : 'Already have an account? ');
        var link = document.createElement('a');
        link.href = '#';
        link.textContent = mode === 'login' ? 'Sign up' : 'Log in';
        link.style.cssText = 'color:#7cd1e2; font-weight:bold;';
        link.onclick = function(e) { e.preventDefault(); openAuth(mode === 'login' ? 'register' : 'login'); };
        toggle.appendChild(label);
        toggle.appendChild(link);
        document.getElementById('authModal').style.display = 'flex';
      }
      function closeAuth() {
        document.getElementById('authModal').style.display = 'none';
      }
      function submitAuth() {
        var email = document.getElementById('authEmail').value.trim().toLowerCase();
        var pass = document.getElementById('authPass').value;
        var err = document.getElementById('authError');
        if (!email || !pass) { err.textContent = 'Please fill in both fields.'; return; }
        var url = authMode === 'login' ? '/api/login' : '/api/register';
        fetch(url, {
          method: 'POST',
          credentials: 'include',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: email, password: pass })
        }).then(function(r) {
          return r.text().then(function(text) {
            console.log('Auth response status:', r.status, 'body:', text);
            if (!text) {
              err.textContent = 'Server returned empty response (status ' + r.status + ')';
              return;
            }
            try {
              var data = JSON.parse(text);
              if (data.success) {
                closeAuth();
                currentIsAdmin = data.isAdmin || false;
                updateUserUI(data.username || email);
                updateAdminNav();
                document.getElementById('authPrompt').style.display = 'none';
                if (document.getElementById('mainApp').style.display === 'none') {
                  startCoding();
                }
              } else {
                err.textContent = data.error || 'Something went wrong.';
              }
            } catch(parseErr) {
              err.textContent = 'Server error (status ' + r.status + '): ' + text.slice(0, 120);
            }
          });
        }).catch(function(e) {
          console.error('Auth fetch error:', e);
          err.textContent = 'Network error: ' + (e.message || 'Request failed');
        });
      }
      var currentIsAdmin = false;
      function updateUserUI(username) {
        var el = document.getElementById('userStatus');
        if (username) {
          el.innerHTML = '<b>' + username + '</b> &nbsp; <a href="#" onclick="doLogout(); return false;" style="color:#888;font-size:0.85em;">Log out</a>';
        } else {
          el.innerHTML = '<a href="#" class="nav-login-btn" onclick="openAuth(\'login\'); return false;" style="color:#fff;background:#ff6f00;padding:6px 16px;border-radius:5px;font-weight:bold;text-decoration:none;display:inline-block;">Log in</a>';
        }
      }
      function updateAdminNav() {
        var adminLink = document.getElementById('adminNavLink');
        if (adminLink) {
          adminLink.style.display = currentIsAdmin ? '' : 'none';
        }
      }
      function doLogout() {
        fetch('/api/logout', { method: 'POST', credentials: 'include' }).then(function() {
          updateUserUI('');
          currentIsAdmin = false;
          updateAdminNav();
          document.getElementById('authPrompt').style.display = '';
        });
      }
      function checkSession() {
        fetch('/api/me', { credentials: 'include' }).then(function(r) {
          if (r.ok) return r.json();
          throw new Error();
        }).then(function(data) {
          if (data.username) {
            currentIsAdmin = data.isAdmin || false;
            updateUserUI(data.username);
            updateAdminNav();
            document.getElementById('authPrompt').style.display = 'none';
          } else {
            updateUserUI('');
            currentIsAdmin = false;
            updateAdminNav();
          }
        }).catch(function() {
          updateUserUI('');
          currentIsAdmin = false;
          updateAdminNav();
        });
      }
      checkSession();

    // -- Vocab Bot Section --
    var vocabBotCode = {
      basic: `# ============================================
#  AI VOCABULARY LEARNER BOT
#  Teach it words and it remembers + quizzes you!
# ============================================

class VocabBot:
    """A simple AI bot that learns words and their meanings."""

    def __init__(self):
        self.vocab = {
            "algorithm": "A step-by-step set of instructions to solve a problem",
            "variable":  "A container that stores a value you can use later",
            "function":  "A reusable block of code that does one specific job",
            "loop":      "Code that repeats itself until a condition is met",
            "list":      "An ordered collection of multiple values",
            "boolean":   "A value that is only True or False",
            "string":    "A sequence of text characters inside quotes",
            "integer":   "A whole number without decimals",
        }
        self.score = 0
        self.tries = 0

    def learn(self, word, meaning):
        self.vocab[word.lower()] = meaning
        print(f"Learned: '{word}' = {meaning}")

    def lookup(self, word):
        w = word.lower()
        if w in self.vocab:
            return f"'{word}' means: {self.vocab[w]}"
        return f"I don't know '{word}' yet!"

    def quiz(self, num=3):
        import random
        words = list(self.vocab.keys())
        if len(words) < num:
            num = len(words)
        picks = random.sample(words, num)
        print("=" * 45)
        print("   VOCAB QUIZ")
        print("=" * 45)
        for word in picks:
            meaning = self.vocab[word]
            print(f"  Q: What does '{word}' mean?")
            self.tries += 1
            self.score += 1
            print(f"  Correct! -> {meaning}")
        print(f"  Score: {self.score}/{self.tries}")

    def stats(self):
        print(f"Bot knows {len(self.vocab)} words")
        print(f"Quiz score: {self.score}/{self.tries} correct")

    def all_words(self):
        for w in sorted(self.vocab):
            print(f"  {w:15s} = {self.vocab[w]}")


# --- USE THE BOT ---
print("=" * 45)
print("   WELCOME TO YOUR VOCAB BOT")
print("=" * 45)

bot = VocabBot()
print(bot.lookup("algorithm"))
print(bot.lookup("loop"))
print(bot.lookup("neural"))

bot.learn("neural", "Relating to neurons or artificial neural networks in AI")
print(bot.lookup("neural"))

print()
bot.all_words()
print()
bot.quiz(3)
print()
bot.stats()`,

      dict: `# Vocabulary Bot - Part 1: Using a Dictionary
# This version stores word-meaning pairs in a plain dictionary.

vocab = {
    "algorithm": "A step-by-step set of instructions to solve a problem",
    "variable":  "A container that stores a value you can use later",
    "function":  "A reusable block of code that does one specific job",
    "loop":      "Code that repeats itself until a condition is met",
}

word = "algorithm"
print(f"'{word}' means: {vocab[word]}")

vocab["recursion"] = "A function that calls itself to solve a problem"
print(f"Added 'recursion'! Now the bot knows {len(vocab)} words.")

print("\\nAll words the bot knows:")
for w in sorted(vocab):
    print(f"  - {w}")

if "loop" in vocab:
    print(f"\\nYes, I know 'loop': {vocab['loop']}")`,

      class: `# Vocabulary Bot - Part 2: Using a Class
# Same dictionary idea, but wrapped in a VocabBot class.

class VocabBot:
    def __init__(self):
        self.vocab = {
            "algorithm": "A step-by-step set of instructions to solve a problem",
            "variable":  "A container that stores a value you can use later",
        }

    def learn(self, word, meaning):
        self.vocab[word.lower()] = meaning
        print(f"Learned: '{word}' = {meaning}")

    def lookup(self, word):
        w = word.lower()
        if w in self.vocab:
            return f"'{word}' means: {self.vocab[w]}"
        return f"I don't know '{word}' yet!"

    def list_words(self):
        print("Words I know:")
        for w in sorted(self.vocab):
            print(f"  - {w}")

bot = VocabBot()
print(bot.lookup("loop"))
print()

bot.learn("recursion", "A function that calls itself")
bot.learn("iteration", "Repeating with a loop")

print()
bot.list_words()
print(f"\\nThe bot knows {len(bot.vocab)} words.")`,

      quiz: `# Vocabulary Bot - Part 4: Interactive Quiz
# Popup dialogs ask you to define words. The bot scores you!

import random

class VocabBot:
    def __init__(self):
        self.vocab = {
            "algorithm": "a step-by-step set of instructions to solve a problem",
            "variable":  "a container that stores a value you can use later",
            "function":  "a reusable block of code that does one specific job",
            "loop":      "code that repeats itself until a condition is met",
        }
        self.score = 0

    def learn(self, word, meaning):
        self.vocab[word.lower()] = meaning.lower()
        print(f"  Taught: '{word}' = {meaning}")

    def _check(self, user_answer, correct):
        user_words = set(user_answer.lower().split())
        key_words  = [w for w in correct.split() if len(w) > 4]
        return any(kw in user_words for kw in key_words) or user_answer.lower() in correct

    def run_quiz(self, num=4):
        words = random.sample(list(self.vocab.keys()), min(num, len(self.vocab)))
        print("=" * 47)
        print("   INTERACTIVE VOCAB QUIZ")
        print("   A popup will appear for each question.")
        print("=" * 47)

        for i, word in enumerate(words, 1):
            correct = self.vocab[word]
            print(f"\\nQuestion {i} of {num}: What does '{word}' mean?")
            answer = input(f"Q{i}: What does '{word}' mean?").strip()

            if not answer:
                print(f"  Skipped. Correct: {correct.capitalize()}")
            elif self._check(answer, correct):
                print(f"  Correct! Great job.")
                print(f"  Official: {correct.capitalize()}")
                self.score += 1
            else:
                print(f"  Not quite.")
                print(f"  You said:  {answer}")
                print(f"  Should be: {correct.capitalize()}")

        print("\\n" + "=" * 47)
        pct = int(self.score / num * 100)
        print(f"  Final Score: {self.score}/{num}  ({pct}%)")
        if self.score == num:
            print("  Perfect score!")
        elif self.score >= num // 2:
            print("  Nice work! Keep practicing.")
        else:
            print("  Keep studying -- you will get there!")
        print("=" * 47)


# ---- Start the bot ----
bot = VocabBot()

print("=" * 47)
print("   WELCOME TO THE VOCAB QUIZ BOT")
print("   Popup dialogs appear when you run!")
print("=" * 47)

want_word = input("Add your own word before the quiz? (yes/no)").strip().lower()
if want_word in ("yes", "y"):
    new_word    = input("Enter a vocabulary word:").strip()
    new_meaning = input(f"What does '{new_word}' mean?").strip()
    bot.learn(new_word, new_meaning)
    print()

bot.run_quiz(4)`
    };

    var vocabBotExplain = {
      basic: '<strong>Full Demo:</strong> A complete VocabBot with lookup, learn, quiz, and stats.\n<strong>Try it:</strong> Change the words in <code>bot.lookup()</code> or teach new ones with <code>bot.learn()</code>.\n<strong>Concepts:</strong> Classes, methods, dictionaries, <code>random.sample()</code>.',
      dict: '<strong>Dictionary Only:</strong> The simplest way to store word-meaning pairs. No classes needed!\n<strong>Try it:</strong> Add your own word to <code>vocab</code>.\n<strong>Concepts:</strong> Dictionaries, <code>key in dict</code>, <code>for key, value in dict.items()</code>.',
      class: '<strong>Class Version:</strong> Wraps the dictionary in a <code>VocabBot</code> class with methods.\n<strong>Try it:</strong> Create a second bot and give each different words.\n<strong>Concepts:</strong> Classes, <code>__init__</code>, <code>self</code>, methods.',
      quiz: '<strong>Interactive Quiz:</strong> Live popup dialogs ask you to define words, and the bot scores you!\n<strong>Try it:</strong> Add your own word before the quiz starts.\n<strong>Concepts:</strong> <code>input()</code>, <code>random.sample()</code>, string comparison, class methods.'
    };

    function updateVocabPreview() {
      var preview = document.querySelector('#vocabPreviewCode code');
      if (preview) {
        preview.textContent = document.getElementById('vocabCodeInput').value;
        Prism.highlightElement(preview);
      }
    }

    document.getElementById('vocabCodeInput').addEventListener('input', updateVocabPreview);

    function loadVocabBot(mode) {
      document.getElementById('vocabCodeInput').value = vocabBotCode[mode] || '';
      updateVocabPreview();
      var explainBox = document.getElementById('vocabExplain');
      if (vocabBotExplain[mode]) {
        explainBox.style.display = '';
        explainBox.innerHTML = vocabBotExplain[mode].replace(/\n/g, '<br>');
      } else {
        explainBox.style.display = 'none';
      }
      // Auto-run after a short delay so the user sees the code appear first
      setTimeout(function() {
        runVocabBot();
      }, 300);
    }

    async function runVocabBot() {
      if (!pyodideReady) return;
      var runBtn = document.getElementById('vocabRunBtn');
      var outBox = document.getElementById('vocabOutput');
      runBtn.disabled = true;
      runBtn.textContent = "Running...";
      outBox.style.display = 'block';
      outBox.textContent = "";
      var code = document.getElementById('vocabCodeInput').value;
      try {
        await pyodide.runPythonAsync(`
import sys, io, traceback
_stdout = sys.stdout
_stderr = sys.stderr
sys.stdout = io.StringIO()
sys.stderr = io.StringIO()
__result__ = ''
__err__ = ''
try:
` + code.split('\n').map(function(l){ return '    ' + l; }).join('\n') + `
except SystemExit:
    pass
except BaseException:
    __err__ = traceback.format_exc()
finally:
    __result__ = sys.stdout.getvalue()
    if not __err__:
        __err__ = sys.stderr.getvalue()
    sys.stdout = _stdout
    sys.stderr = _stderr
`);
        var output = pyodide.globals.get('__result__') || '';
        var error = pyodide.globals.get('__err__') || '';
        outBox.textContent = output + (error ? "\nError:\n" + error : "");
      } catch (err) {
        outBox.textContent = "Error:\n" + err;
      } finally {
        runBtn.disabled = false;
        runBtn.textContent = "Run \ud83d\udfe2";
      }
    }

    function copyVocabCode() {
      var ta = document.getElementById('vocabCodeInput');
      ta.select();
      document.execCommand('copy');
    }

    function clearVocabCode() {
      document.getElementById('vocabCodeInput').value = '';
      updateVocabPreview();
      document.getElementById('vocabOutput').style.display = 'none';
      document.getElementById('vocabExplain').style.display = 'none';
    }

    // -- Vocab Bot Word Tracking & Leaderboards --
    function extractWordsFromOutput(output) {
      var words = [];
      // Match "Learned: 'word' = meaning" pattern
      var re = /Learned:\s*['"]([^'"]+)['"]\s*=\s*(.+)/gi;
      var m;
      while ((m = re.exec(output)) !== null) {
        words.push({ word: m[1].trim().toLowerCase(), meaning: m[2].trim() });
      }
      return words;
    }

    function recordVocabWords(output) {
      var words = extractWordsFromOutput(output);
      if (!words.length) return;
      // Send words to server one at a time
      words.forEach(function(entry) {
        fetch('/api/vocab/word', {
          method: 'POST',
          credentials: 'include',
          headers: {'Content-Type': 'application/json'},
          body: JSON.stringify({ word: entry.word, meaning: entry.meaning })
        }).then(function(r) {
          if (r.ok) return r.json();
        }).then(function(data) {
          if (data && data.success) {
            updateVocabStats(data.total, data.weekly);
          }
        }).catch(function() {});
      });
    }

    function updateVocabStats(total, weekly) {
      document.getElementById('vocabTotalWords').textContent = total || 0;
      document.getElementById('vocabWeeklyWords').textContent = weekly || 0;
    }

    function fetchVocabStats() {
      fetch('/api/vocab/stats', { credentials: 'include' }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        updateVocabStats(data.total, data.weekly);
        document.getElementById('vocabStatsBox').style.display = '';
        document.getElementById('vocabLoginNote').style.display = 'none';
        // Populate recent words
        var recentBox = document.getElementById('vboard-recent-list');
        if (data.recent && data.recent.length) {
          recentBox.innerHTML = data.recent.map(function(e) {
            return '<div style="padding:6px 8px; border-bottom:1px solid #ddd; display:flex; justify-content:space-between;"><b>' + escapeHtml(e.word) + '</b><span style="color:#555; font-size:0.9em;">' + escapeHtml(e.meaning) + '</span></div>';
          }).join('');
        } else {
          recentBox.innerHTML = '<p style="text-align:center; color:#888; margin:0;">No words recorded yet. Run a bot that teaches a word!</p>';
        }
      }).catch(function() {
        document.getElementById('vocabStatsBox').style.display = '';
        document.getElementById('vocabLoginNote').style.display = '';
      });
    }

    function escapeHtml(text) {
      var div = document.createElement('div');
      div.textContent = text;
      return div.innerHTML;
    }

    function showVocabBoard(mode) {
      ['lifetime', 'weekly', 'recent'].forEach(function(m) {
        document.getElementById('vboard-' + m).style.display = (m === mode) ? '' : 'none';
        var btn = document.getElementById('vboard-btn-' + m);
        if (btn) btn.style.opacity = (m === mode) ? '1' : '0.6';
      });
      if (mode === 'lifetime') fetchVocabLeaderboard('lifetime');
      if (mode === 'weekly') fetchVocabLeaderboard('weekly');
    }

    function fetchVocabLeaderboard(mode) {
      fetch('/api/vocab/leaderboard/' + mode, { credentials: 'include' }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        var tbody = document.getElementById('vboard-' + mode + '-body');
        if (!data.leaderboard || !data.leaderboard.length) {
          tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding:16px; color:#888;">No entries yet. Be the first to teach a word!</td></tr>';
          return;
        }
        var myUser = '';
        var userStatus = document.getElementById('userStatus');
        if (userStatus) {
          var b = userStatus.querySelector('b');
          if (b) myUser = b.textContent.trim().toLowerCase();
        }
        tbody.innerHTML = data.leaderboard.map(function(e, i) {
          var isMe = e.username.toLowerCase() === myUser;
          var style = isMe ? 'background:#fff9c4; font-weight:600;' : (i % 2 === 0 ? '' : 'background:#f8f9fa;');
          return '<tr style="' + style + '"><td style="padding:8px 12px;">' + (i + 1) + '</td><td style="padding:8px 12px;">' + escapeHtml(e.username) + (isMe ? ' (you)' : '') + '</td><td style="padding:8px 12px; text-align:right; font-weight:600;">' + e.words + '</td></tr>';
        }).join('');
      }).catch(function() {
        var tbody = document.getElementById('vboard-' + mode + '-body');
        if (tbody) tbody.innerHTML = '<tr><td colspan="3" style="text-align:center; padding:16px; color:#888;">Log in to see leaderboards</td></tr>';
      });
    }

    function toggleVocabLeaderboards(show) {
      var box = document.getElementById('vocabLeaderboards');
      if (!box) return;
      if (show) {
        box.style.display = '';
        showVocabBoard('lifetime');
      } else {
        box.style.display = 'none';
      }
    }

    // Hook into runVocabBot to track words
    var originalRunVocabBot = runVocabBot;
    runVocabBot = async function() {
      if (!pyodideReady) return;
      var runBtn = document.getElementById('vocabRunBtn');
      var outBox = document.getElementById('vocabOutput');
      runBtn.disabled = true;
      runBtn.textContent = "Running...";
      outBox.style.display = 'block';
      outBox.textContent = "";
      var code = document.getElementById('vocabCodeInput').value;
      try {
        await pyodide.runPythonAsync(`
import sys, io, traceback
_stdout = sys.stdout
_stderr = sys.stderr
sys.stdout = io.StringIO()
sys.stderr = io.StringIO()
__result__ = ''
__err__ = ''
try:
` + code.split('\n').map(function(l){ return '    ' + l; }).join('\n') + `
except SystemExit:
    pass
except BaseException:
    __err__ = traceback.format_exc()
finally:
    __result__ = sys.stdout.getvalue()
    if not __err__:
        __err__ = sys.stderr.getvalue()
    sys.stdout = _stdout
    sys.stderr = _stderr
`);
        var output = pyodide.globals.get('__result__') || '';
        var error = pyodide.globals.get('__err__') || '';
        outBox.textContent = output + (error ? "\nError:\n" + error : "");
        // Track words from output
        if (output) recordVocabWords(output);
      } catch (err) {
        outBox.textContent = "Error:\n" + err;
      } finally {
        runBtn.disabled = false;
        runBtn.textContent = "Run \ud83d\udfe2";
      }
    };

    // Show stats/leaderboards when user is logged in and on vocab page
    function addManualWord() {
      var wordInput = document.getElementById('manualWord');
      var meaningInput = document.getElementById('manualMeaning');
      var msg = document.getElementById('manualWordMsg');
      var word = wordInput.value.trim().toLowerCase();
      var meaning = meaningInput.value.trim();
      if (!word) { msg.textContent = 'Please enter a word.'; msg.style.color = '#c62828'; return; }
      if (!meaning) { msg.textContent = 'Please enter a meaning.'; msg.style.color = '#c62828'; return; }
      fetch('/api/vocab/word', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ word: word, meaning: meaning })
      }).then(function(r) {
        if (r.ok) return r.json();
        throw new Error();
      }).then(function(data) {
        if (data.success) {
          msg.textContent = "Saved '" + word + "'! You now have " + data.total + " lifetime words.";
          msg.style.color = '#2e7d32';
          updateVocabStats(data.total, data.weekly);
          wordInput.value = '';
          meaningInput.value = '';
          fetchVocabStats();
        } else {
          msg.textContent = data.error || 'Could not save word.';
          msg.style.color = '#c62828';
        }
      }).catch(function() {
        msg.textContent = 'Log in to add words to your score!';
        msg.style.color = '#c62828';
      });
    }

    function sendChatMessage() {
      var input = document.getElementById('vocabChatInput');
      var msg = input.value.trim();
      if (!msg) return;
      input.value = '';
      appendChatBubble(msg, 'user');
      fetch('/api/vocab/chat', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg })
      }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        appendChatBubble(data.reply || '...', 'bot');
        if (data.wordCount !== undefined) {
          document.getElementById('vocabTotalWords').textContent = data.wordCount;
        }
      }).catch(function() {
        appendChatBubble('Log in to chat with the bot!', 'bot');
      });
    }

    function appendChatBubble(text, sender) {
      var box = document.getElementById('vocabChatMessages');
      var bubble = document.createElement('div');
      if (sender === 'user') {
        bubble.style.cssText = 'background:#1a237e; color:#fff; border-radius:12px 12px 2px 12px; padding:10px 14px; margin-bottom:10px; display:inline-block; max-width:85%; font-size:0.95em; float:right; clear:both;';
      } else {
        bubble.style.cssText = 'background:#e3f2fd; border-radius:12px 12px 12px 2px; padding:10px 14px; margin-bottom:10px; display:inline-block; max-width:85%; color:#1565c0; font-size:0.95em; clear:both;';
      }
      bubble.textContent = text;
      box.appendChild(bubble);
      box.scrollTop = box.scrollHeight;
    }

    function onVocabPageShown() {
      var sess = document.getElementById('userStatus').querySelector('b');
      if (sess) {
        fetchVocabStats();
        toggleVocabLeaderboards(true);
      } else {
        document.getElementById('vocabStatsBox').style.display = '';
        document.getElementById('vocabLoginNote').style.display = '';
        document.getElementById('vocabLeaderboards').style.display = 'none';
      }
      document.getElementById('vocabChatBox').style.display = '';
    }

    // -- Admin Panel Section --
    function onAdminPageShown() {
      if (!currentIsAdmin) {
        showSection('sec-editor');
        return;
      }
      loadAdminStats();
      loadAdminUsers();
    }
    function loadAdminStats() {
      fetch('/api/admin/stats', { credentials: 'include' }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        document.getElementById('adminTotalVisits').textContent = data.totalVisits || 0;
        document.getElementById('adminUniqueVisitors').textContent = data.uniqueVisitors || 0;
        document.getElementById('adminTotalUsers').textContent = data.totalUsers || 0;
        document.getElementById('adminTotalWords').textContent = data.totalWords || 0;
        document.getElementById('adminActiveWeekly').textContent = data.activeWeekly || 0;
        document.getElementById('adminOnlineNow').textContent = data.onlineNow || 0;
      }).catch(function() {});
    }
    function loadAdminUsers() {
      fetch('/api/admin/users', { credentials: 'include' }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        var tbody = document.getElementById('adminUsersBody');
        tbody.innerHTML = '';
        if (!data.users || data.users.length === 0) {
          tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;padding:16px;color:#888;">No users yet.</td></tr>';
          return;
        }
        data.users.forEach(function(u) {
          var tr = document.createElement('tr');
          tr.style.cssText = 'border-bottom:1px solid #eee;';
          var statusText = u.isBlocked ? '<span style="color:#d32f2f;font-weight:bold;">Blocked</span>' : '<span style="color:#2e7d32;">Active</span>';
          var btnHtml = u.isBlocked
            ? '<button onclick="unblockUser(' + u.id + ', \'' + u.username + '\')" style="background:#2e7d32;color:#fff;border:none;border-radius:4px;padding:3px 10px;cursor:pointer;font-size:0.8em;">Unblock</button>'
            : '<button onclick="blockUser(' + u.id + ', \'' + u.username + '\')" style="background:#d32f2f;color:#fff;border:none;border-radius:4px;padding:3px 10px;cursor:pointer;font-size:0.8em;">Block</button>';
          tr.innerHTML = '<td style="padding:6px 10px;">' + u.id + '</td>' +
            '<td style="padding:6px 10px;">' + u.username + '</td>' +
            '<td style="padding:6px 10px;">' + (u.email || '') + '</td>' +
            '<td style="padding:6px 10px;text-align:center;">' + (u.wordCount || 0) + '</td>' +
            '<td style="padding:6px 10px;text-align:center;font-size:0.85em;color:#888;">' + (u.createdAt || '').slice(0, 10) + '</td>' +
            '<td style="padding:6px 10px;text-align:center;">' + statusText + '</td>' +
            '<td style="padding:6px 10px;text-align:center;">' + btnHtml + '</td>';
          tbody.appendChild(tr);
        });
      }).catch(function() {});
    }
    function resetLeaderboard() {
      if (!confirm('WARNING: This will delete ALL word data for every user. This cannot be undone. Continue?')) {
        return;
      }
      fetch('/api/admin/reset-leaderboard', { method: 'POST', credentials: 'include' }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        document.getElementById('adminActionMsg').textContent = data.message || 'Done';
        loadAdminStats();
        loadAdminUsers();
      }).catch(function(e) {
        document.getElementById('adminActionMsg').textContent = 'Error: ' + (e.message || 'Failed');
      });
    }
    function blockUser(userId, username) {
      if (!confirm('Block user ' + username + '? They will not be able to log in.')) {
        return;
      }
      fetch('/api/admin/block-user', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userId })
      }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        document.getElementById('adminActionMsg').textContent = 'Blocked ' + username;
        loadAdminUsers();
      }).catch(function(e) {
        document.getElementById('adminActionMsg').textContent = 'Error blocking user';
      });
    }
    function unblockUser(userId, username) {
      fetch('/api/admin/unblock-user', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: userId })
      }).then(function(r) {
        if (!r.ok) throw new Error();
        return r.json();
      }).then(function(data) {
        document.getElementById('adminActionMsg').textContent = 'Unblocked ' + username;
        loadAdminUsers();
      }).catch(function(e) {
        document.getElementById('adminActionMsg').textContent = 'Error unblocking user';
      });
    }
  